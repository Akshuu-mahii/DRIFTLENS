import React from 'react';
import { Play, GitBranch, RefreshCw, Sparkles, Activity, CheckCircle2, AlertCircle, FileText } from 'lucide-react';
import { ProjectConfig } from '../types';

interface HeaderProps {
  project: ProjectConfig | null;
  onTriggerScan: () => void;
  isScanning: boolean;
  onOpenFixes: () => void;
  onOpenReport?: () => void;
  unresolvedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  project,
  onTriggerScan,
  isScanning,
  onOpenFixes,
  onOpenReport,
  unresolvedCount,
}) => {
  const healthColor =
    (project?.healthScore ?? 0) >= 85
      ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
      : (project?.healthScore ?? 0) >= 70
      ? 'text-amber-400 border-amber-500/30 bg-amber-500/10'
      : 'text-rose-400 border-rose-500/30 bg-rose-500/10';

  return (
    <header className="h-16 bg-[#0c1017]/80 backdrop-blur-md border-b border-[#1e293b]/70 px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Left: Project & Branch info */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <h1 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            {project?.name || 'DriftLens Core'}
          </h1>
          <span className="text-slate-500 text-sm">/</span>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#131b2a] border border-[#243046] text-slate-300 text-xs font-mono">
            <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
            <span>{project?.branch || 'main'}</span>
          </div>
        </div>

        {/* Environment Status Pills */}
        <div className="hidden lg:flex items-center gap-2 pl-3 border-l border-[#1e293b]">
          <span className="text-[11px] text-slate-400 font-medium mr-1">Environments:</span>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#101725] border border-emerald-900/40 text-[11px] text-emerald-300 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Dev ({project?.environments?.development?.varsCount ?? 42} keys)</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#101725] border border-amber-900/40 text-[11px] text-amber-300 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            <span>Staging ({project?.environments?.staging?.varsCount ?? 38} keys)</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#101725] border border-rose-900/40 text-[11px] text-rose-300 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
            <span>Prod ({project?.environments?.production?.varsCount ?? 36} keys)</span>
          </div>
        </div>
      </div>

      {/* Right: Health badge & Quick Actions */}
      <div className="flex items-center gap-3">
        {/* Health pill */}
        <div
          className={`flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-semibold ${healthColor}`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Health: {project?.healthScore ?? 74}%</span>
        </div>

        {/* AI Recommendations jump */}
        {unresolvedCount > 0 && (
          <button
            id="header-ai-fixes-btn"
            onClick={onOpenFixes}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 transition-all shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span>AI Fixes ({unresolvedCount})</span>
          </button>
        )}

        {/* Safe Audit Report Button */}
        {onOpenReport && (
          <button
            id="header-safe-report-btn"
            onClick={onOpenReport}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 transition-all shadow-sm"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            <span>Safe Report</span>
          </button>
        )}

        {/* Quick Scan Button */}
        <button
          id="header-run-scan-btn"
          onClick={onTriggerScan}
          disabled={isScanning}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold tracking-tight transition-all shadow-md ${
            isScanning
              ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/20 active:scale-95'
          }`}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? 'Scanning Codebase...' : 'Scan Project'}</span>
        </button>
      </div>
    </header>
  );
};
