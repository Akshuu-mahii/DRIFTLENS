import React, { useState } from 'react';
import {
  AlertTriangle,
  XCircle,
  HelpCircle,
  Zap,
  Search,
  CheckCircle2,
  Clock,
  ArrowRight,
  GitFork,
  Sparkles,
  ExternalLink,
  Code2,
  FileCode,
  Tag,
  ShieldAlert,
} from 'lucide-react';
import { DriftIssue, DriftType, Severity, IssueStatus } from '../types';
import { NavRoute } from './Sidebar';

interface IssuesViewProps {
  issues: DriftIssue[];
  onNavigate: (route: NavRoute) => void;
  onSelectIssueForMindMap?: (issue: DriftIssue) => void;
  onSelectIssueForFix?: (issue: DriftIssue) => void;
  onApplyFix: (issueId: string) => void;
}

export const IssuesView: React.FC<IssuesViewProps> = ({
  issues,
  onNavigate,
  onSelectIssueForMindMap,
  onSelectIssueForFix,
  onApplyFix,
}) => {
  const [activeTab, setActiveTab] = useState<DriftType | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<IssueStatus | 'all'>('all');
  const [severityFilter, setSeverityFilter] = useState<Severity | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const missingCount = issues.filter((i) => i.type === 'missing').length;
  const orphanedCount = issues.filter((i) => i.type === 'orphaned').length;
  const typeMismatchCount = issues.filter((i) => i.type === 'type_mismatch').length;

  const filteredIssues = issues.filter((issue) => {
    if (activeTab !== 'all' && issue.type !== activeTab) return false;
    if (statusFilter !== 'all' && issue.status !== statusFilter) return false;
    if (severityFilter !== 'all' && issue.severity !== severityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        issue.title.toLowerCase().includes(q) ||
        issue.keyOrTarget.toLowerCase().includes(q) ||
        issue.filePath.toLowerCase().includes(q) ||
        issue.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getSeverityBadge = (sev: Severity) => {
    switch (sev) {
      case 'critical':
        return 'bg-rose-950/60 text-rose-300 border-rose-800/60';
      case 'high':
        return 'bg-orange-950/60 text-orange-300 border-orange-800/60';
      case 'medium':
        return 'bg-amber-950/60 text-amber-300 border-amber-800/60';
      case 'low':
        return 'bg-blue-950/60 text-blue-300 border-blue-800/60';
    }
  };

  const getStatusBadge = (st: IssueStatus) => {
    switch (st) {
      case 'new':
        return 'bg-cyan-950/60 text-cyan-300 border-cyan-800/60';
      case 'still_unresolved':
        return 'bg-rose-950/60 text-rose-300 border-rose-800/60';
      case 'resolved':
        return 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
      case 'ignored':
        return 'bg-slate-900 text-slate-400 border-slate-700';
    }
  };

  const getStatusLabel = (st: IssueStatus) => {
    switch (st) {
      case 'new':
        return 'New';
      case 'still_unresolved':
        return 'Still Unresolved';
      case 'resolved':
        return 'Resolved';
      case 'ignored':
        return 'Ignored';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <AlertTriangle className="w-6 h-6 text-rose-400" />
            Detected Codebase & Configuration Drift
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Categorized anomalies identified across source files, package manifests, and environment configurations.
          </p>
        </div>

        <button
          onClick={() => onNavigate('fixes')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 shadow-md transition-all active:scale-95"
        >
          <Sparkles className="w-4 h-4" />
          <span>Batch Fix AI Assistant</span>
        </button>
      </div>

      {/* Main Tabs for Drift Categories: Missing, Orphaned, Type Mismatch */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1e293b] pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'all'
                ? 'bg-[#1e293b] text-white border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#111827]'
            }`}
          >
            <span>All Issues</span>
            <span className="px-1.5 py-0.2 rounded font-mono text-[10px] bg-slate-800 text-slate-300">
              {issues.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('missing')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'missing'
                ? 'bg-rose-950/40 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'text-slate-400 hover:text-rose-300 hover:bg-[#111827]'
            }`}
          >
            <XCircle className="w-3.5 h-3.5 text-rose-400" />
            <span>Missing</span>
            <span className="px-1.5 py-0.2 rounded font-mono text-[10px] bg-rose-950 text-rose-300 border border-rose-800/40">
              {missingCount}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('orphaned')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'orphaned'
                ? 'bg-amber-950/40 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-amber-300 hover:bg-[#111827]'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>Orphaned</span>
            <span className="px-1.5 py-0.2 rounded font-mono text-[10px] bg-amber-950 text-amber-300 border border-amber-800/40">
              {orphanedCount}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('type_mismatch')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'type_mismatch'
                ? 'bg-purple-950/40 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'text-slate-400 hover:text-purple-300 hover:bg-[#111827]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-purple-400" />
            <span>Type Mismatch</span>
            <span className="px-1.5 py-0.2 rounded font-mono text-[10px] bg-purple-950 text-purple-300 border border-purple-800/40">
              {typeMismatchCount}
            </span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search key, file, or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#101726] border border-[#222e44] rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
          />
        </div>
      </div>

      {/* Sub-Filters: Status & Severity */}
      <div className="flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Status:</span>
          {(['all', 'still_unresolved', 'new', 'resolved'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg capitalize font-mono text-[11px] transition-colors ${
                statusFilter === st
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 bg-[#111827] border border-[#1e293b]'
              }`}
            >
              {st === 'all' ? 'All Statuses' : st.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Severity:</span>
          {(['all', 'critical', 'high', 'medium', 'low'] as const).map((sev) => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2.5 py-1 rounded-lg capitalize font-mono text-[11px] transition-colors ${
                severityFilter === sev
                  ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 bg-[#111827] border border-[#1e293b]'
              }`}
            >
              {sev === 'all' ? 'All' : sev}
            </button>
          ))}
        </div>
      </div>

      {/* Issues List */}
      <div className="space-y-4">
        {filteredIssues.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#111827] border border-[#1e293b] space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h3 className="text-base font-bold text-white">No Issues Found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No configuration drift issues match your current filters. Try changing category tabs or search query.
            </p>
          </div>
        ) : (
          filteredIssues.map((issue) => {
            const isResolved = issue.status === 'resolved';

            return (
              <div
                key={issue.id}
                className={`p-6 rounded-2xl border transition-all ${
                  isResolved
                    ? 'bg-[#0d131f]/60 border-emerald-900/40 opacity-75'
                    : 'bg-[#111827] border-[#1e293b] hover:border-slate-600 shadow-lg'
                }`}
              >
                {/* Top Row: Title, Badges, Status */}
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-3 mb-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/50 px-2 py-0.5 rounded border border-cyan-800/40">
                        {issue.keyOrTarget}
                      </span>
                      <span className={`text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded border ${getSeverityBadge(issue.severity)}`}>
                        {issue.severity}
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getStatusBadge(issue.status)}`}>
                        {getStatusLabel(issue.status)} {issue.repeatCount > 1 && `(${issue.repeatCount}x detected)`}
                      </span>
                      <span className="text-[10px] font-mono uppercase text-slate-400 px-1.5 py-0.5 rounded bg-[#162032] border border-slate-700/50">
                        {issue.category.replace('_', ' ')}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white tracking-tight pt-1">
                      {issue.title}
                    </h3>
                  </div>

                  {/* Actions right */}
                  <div className="flex flex-wrap items-center gap-2 flex-shrink-0">
                    <button
                      id={`issue-mindmap-btn-${issue.id}`}
                      onClick={() => {
                        if (onSelectIssueForMindMap) onSelectIssueForMindMap(issue);
                        onNavigate('mind-map');
                      }}
                      className="px-3.5 py-2 rounded-xl text-xs font-bold text-cyan-300 bg-cyan-950/50 hover:bg-cyan-900/60 border border-cyan-500/40 transition-all flex items-center gap-1.5 shadow-sm"
                    >
                      <GitFork className="w-3.5 h-3.5 text-cyan-400" />
                      <span>View in Mind Map</span>
                    </button>

                    {!isResolved && (
                      <button
                        id={`issue-fix-btn-${issue.id}`}
                        onClick={() => {
                          if (onSelectIssueForFix) onSelectIssueForFix(issue);
                          onNavigate('fixes');
                        }}
                        className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 transition-all shadow-md flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
                        <span>Recommended Fix</span>
                      </button>
                    )}

                    {!isResolved ? (
                      <button
                        onClick={() => onApplyFix(issue.id)}
                        className="px-3 py-1.5 rounded-lg text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 transition-colors"
                      >
                        Resolve
                      </button>
                    ) : (
                      <span className="px-2 py-1 text-xs font-mono text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Fixed
                      </span>
                    )}
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-300 mb-4">{issue.description}</p>

                {/* Environment Status Pills */}
                <div className="p-3 rounded-xl bg-[#0a0f18] border border-[#1b2538] mb-4 flex flex-wrap items-center gap-4 text-xs font-mono">
                  <span className="text-slate-400 font-sans font-medium text-[11px]">Affected Environments:</span>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        issue.affectedEnvironments.development ? 'bg-emerald-400' : 'bg-rose-500'
                      }`}
                    />
                    <span className={issue.affectedEnvironments.development ? 'text-slate-300' : 'text-rose-400 font-bold'}>
                      Dev: {issue.affectedEnvironments.development ? 'Present' : 'MISSING'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        issue.affectedEnvironments.staging ? 'bg-emerald-400' : 'bg-rose-500 animate-pulse'
                      }`}
                    />
                    <span className={issue.affectedEnvironments.staging ? 'text-slate-300' : 'text-rose-400 font-bold'}>
                      Staging: {issue.affectedEnvironments.staging ? 'Present' : 'MISSING'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        issue.affectedEnvironments.production ? 'bg-emerald-400' : 'bg-rose-500 animate-pulse'
                      }`}
                    />
                    <span className={issue.affectedEnvironments.production ? 'text-slate-300' : 'text-rose-400 font-bold'}>
                      Prod: {issue.affectedEnvironments.production ? 'Present' : 'MISSING'}
                    </span>
                  </div>
                </div>

                {/* Code Snippet Preview */}
                <div className="rounded-xl bg-[#080c14] border border-[#1c273a] overflow-hidden font-mono text-xs">
                  <div className="px-3 py-1.5 bg-[#0e1422] border-b border-[#1c273a] flex items-center justify-between text-slate-400 text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                      {issue.filePath}:{issue.line}
                    </span>
                    <span>Target AST Reference</span>
                  </div>
                  <pre className="p-3 text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
                    {issue.codeSnippet.surroundingContext || issue.codeSnippet.before}
                  </pre>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
