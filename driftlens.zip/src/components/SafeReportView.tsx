import React, { useState, useMemo } from 'react';
import {
  FileText,
  Download,
  Copy,
  Printer,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Flame,
  ArrowRight,
  ExternalLink,
  Layers,
  Filter,
  Eye,
  RefreshCw,
  GitFork,
  Sparkles,
  Lock,
} from 'lucide-react';
import { ProjectConfig, DriftIssue, SecretItem, ScanRun } from '../types';
import { NavRoute } from './Sidebar';

interface SafeReportViewProps {
  project: ProjectConfig | null;
  issues: DriftIssue[];
  secrets: SecretItem[];
  history: ScanRun[];
  onNavigate: (route: NavRoute) => void;
  onTriggerScan: () => void;
}

export const SafeReportView: React.FC<SafeReportViewProps> = ({
  project,
  issues,
  secrets,
  history,
  onNavigate,
  onTriggerScan,
}) => {
  const [includeResolved, setIncludeResolved] = useState(true);
  const [includeDiffs, setIncludeDiffs] = useState(true);
  const [severityFilter, setSeverityFilter] = useState<'all' | 'critical-high' | 'critical'>('all');
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'markdown'>('preview');

  const reportId = useMemo(() => `DL-REP-${Date.now().toString(36).toUpperCase()}`, []);
  const generatedAt = useMemo(() => new Date().toLocaleString(), []);

  // Filtered issues based on settings
  const filteredIssues = useMemo(() => {
    return issues.filter((issue) => {
      if (!includeResolved && (issue.status === 'resolved' || issue.status === 'ignored')) {
        return false;
      }
      if (severityFilter === 'critical') {
        return issue.severity === 'critical';
      }
      if (severityFilter === 'critical-high') {
        return issue.severity === 'critical' || issue.severity === 'high';
      }
      return true;
    });
  }, [issues, includeResolved, severityFilter]);

  const missingIssues = filteredIssues.filter((i) => i.type === 'missing');
  const orphanedIssues = filteredIssues.filter((i) => i.type === 'orphaned');
  const mismatchIssues = filteredIssues.filter((i) => i.type === 'type_mismatch');
  const criticalCount = filteredIssues.filter((i) => i.severity === 'critical').length;
  const highCount = filteredIssues.filter((i) => i.severity === 'high').length;
  const resolvedCount = issues.filter((i) => i.status === 'resolved').length;
  const exposedSecrets = secrets.filter((s) => s.status === 'exposed');

  // Generate safe Markdown report text (Strictly without raw secret values)
  const markdownReport = useMemo(() => {
    const lines: string[] = [];
    lines.push(`# DriftLens Codebase Health & Configuration Drift Audit Report`);
    lines.push(`**Report ID:** ${reportId}`);
    lines.push(`**Generated:** ${generatedAt}`);
    lines.push(`**Project:** ${project?.name || 'Codebase'} (Branch: \`${project?.branch || 'main'}\`)`);
    lines.push(`**Overall Health Score:** ${project?.healthScore ?? 78}%`);
    lines.push(`**Security Notice:** All secret credentials in this report have been safely masked and audited via Secret Shield. Zero raw credentials are ever exported.`);
    lines.push(``);
    lines.push(`---`);
    lines.push(``);
    lines.push(`## 1. Executive Summary`);
    lines.push(``);
    lines.push(`- **Total Analyzed Files:** ${project?.filesCount || 384}`);
    lines.push(`- **Active Drift Issues Detected:** ${filteredIssues.filter((i) => i.status !== 'resolved').length}`);
    lines.push(`- **Critical Severity Issues:** ${criticalCount}`);
    lines.push(`- **High Severity Issues:** ${highCount}`);
    lines.push(`- **Resolved Issues:** ${resolvedCount}`);
    lines.push(`- **Exposed Credentials Flagged:** ${exposedSecrets.length} (Masked metadata only)`);
    lines.push(``);
    lines.push(`### Environment Parity Overview`);
    lines.push(`| Environment | Configured Keys | Parity Status |`);
    lines.push(`| :--- | :--- | :--- |`);
    lines.push(`| Development | ${project?.environments?.development?.varsCount || 42} keys | ${project?.environments?.development?.status?.toUpperCase() || 'HEALTHY'} |`);
    lines.push(`| Staging | ${project?.environments?.staging?.varsCount || 38} keys | ${project?.environments?.staging?.status?.toUpperCase() || 'DRIFT DETECTED'} |`);
    lines.push(`| Production | ${project?.environments?.production?.varsCount || 36} keys | ${project?.environments?.production?.status?.toUpperCase() || 'CRITICAL DRIFT'} |`);
    lines.push(``);
    lines.push(`---`);
    lines.push(``);
    lines.push(`## 2. Missing Configuration Drifts (${missingIssues.length})`);
    lines.push(`*Configuration keys referenced in application source code that are missing in one or more environments.*`);
    lines.push(``);
    if (missingIssues.length === 0) {
      lines.push(`*No missing configuration drifts matching current filter criteria.*`);
    } else {
      missingIssues.forEach((issue, idx) => {
        lines.push(`### 2.${idx + 1}. \`${issue.keyOrTarget}\` [${issue.severity.toUpperCase()}]`);
        lines.push(`- **Referenced In:** \`${issue.filePath}:${issue.line}\``);
        lines.push(`- **Status:** ${issue.status.toUpperCase()} (Detected ${issue.repeatCount} scan times)`);
        lines.push(`- **Missing In:** ${Object.entries(issue.affectedEnvironments).filter(([, v]) => v === 'missing').map(([env]) => env.toUpperCase()).join(', ')}`);
        lines.push(`- **Runtime Impact:** ${issue.mindMapData.impact}`);
        lines.push(`- **Recommended Action:** ${issue.mindMapData.recommendedAction}`);
        if (includeDiffs && issue.fixSuggestion) {
          lines.push(`- **Safe Remediation Directive:** ${issue.fixSuggestion.safeActionSummary}`);
          lines.push(`\`\`\`diff`);
          lines.push(`--- Before (${issue.fixSuggestion.targetFile})`);
          lines.push(`${issue.fixSuggestion.diffBefore}`);
          lines.push(`+++ After (${issue.fixSuggestion.targetFile})`);
          lines.push(`${issue.fixSuggestion.diffAfter}`);
          lines.push(`\`\`\``);
        }
        lines.push(``);
      });
    }

    lines.push(`---`);
    lines.push(``);
    lines.push(`## 3. Orphaned Configuration Drifts (${orphanedIssues.length})`);
    lines.push(`*Configuration keys or source files declared in environments but never referenced in application code.*`);
    lines.push(``);
    if (orphanedIssues.length === 0) {
      lines.push(`*No orphaned configuration drifts matching current filter criteria.*`);
    } else {
      orphanedIssues.forEach((issue, idx) => {
        lines.push(`### 3.${idx + 1}. \`${issue.keyOrTarget}\` [${issue.severity.toUpperCase()}]`);
        lines.push(`- **Defined Location:** \`${issue.filePath}\``);
        lines.push(`- **Status:** ${issue.status.toUpperCase()}`);
        lines.push(`- **Problem Summary:** ${issue.mindMapData.problem}`);
        lines.push(`- **Evidence:** ${issue.mindMapData.evidence}`);
        lines.push(`- **Recommended Cleanup:** ${issue.mindMapData.recommendedAction}`);
        lines.push(``);
      });
    }

    lines.push(`---`);
    lines.push(``);
    lines.push(`## 4. Type & Value Inconsistencies (${mismatchIssues.length})`);
    lines.push(`*Keys whose types (number vs string vs boolean) or schemas differ across environments.*`);
    lines.push(``);
    if (mismatchIssues.length === 0) {
      lines.push(`*No type mismatches matching current filter criteria.*`);
    } else {
      mismatchIssues.forEach((issue, idx) => {
        lines.push(`### 4.${idx + 1}. \`${issue.keyOrTarget}\` [${issue.severity.toUpperCase()}]`);
        lines.push(`- **Referenced In:** \`${issue.filePath}:${issue.line}\``);
        lines.push(`- **Evidence:** ${issue.mindMapData.evidence}`);
        lines.push(`- **Impact:** ${issue.mindMapData.impact}`);
        lines.push(`- **Action:** ${issue.mindMapData.recommendedAction}`);
        lines.push(``);
      });
    }

    lines.push(`---`);
    lines.push(``);
    lines.push(`## 5. Secret Shield Audit (Sanitized Metadata)`);
    lines.push(`*Automated credential exposure scan. Raw values are strictly withheld from reports.*`);
    lines.push(``);
    lines.push(`| Credential Type | Source Location | Entropy Score | Status | Remediation Protocol |`);
    lines.push(`| :--- | :--- | :--- | :--- | :--- |`);
    secrets.forEach((s) => {
      lines.push(`| ${s.keyName} | \`${s.location}:${s.line}\` | ${s.entropy} (Shannon) | ${s.status.toUpperCase()} | ${s.remediationRecommendation.replace(/\|/g, '-')} |`);
    });
    lines.push(``);
    lines.push(`---`);
    lines.push(``);
    lines.push(`*Report generated by DriftLens — Configuration Drift Detection & Codebase Health Engine.*`);
    return lines.join('\n');
  }, [
    reportId,
    generatedAt,
    project,
    filteredIssues,
    missingIssues,
    orphanedIssues,
    mismatchIssues,
    criticalCount,
    highCount,
    resolvedCount,
    exposedSecrets,
    secrets,
    includeDiffs,
  ]);

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(markdownReport);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([markdownReport], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `driftlens-report-${project?.name.toLowerCase().replace(/\s+/g, '-') || 'codebase'}-${Date.now()}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrintPDF = () => {
    window.print();
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Top Header & Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-[#1e293b]/70">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30">
              AUDIT REPORT
            </span>
            <span>ID: {reportId}</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-cyan-400" />
            Safe Drift & Health Audit Report
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Consolidated configuration drift findings, runtime risk analysis, and safe remediation directives.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="report-copy-md-btn"
            onClick={handleCopyMarkdown}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 bg-[#141d2d] hover:bg-[#1a263b] border border-[#233148] transition-all"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-400" />
                <span>Copy Markdown</span>
              </>
            )}
          </button>

          <button
            id="report-download-md-btn"
            onClick={handleDownloadMarkdown}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 transition-all shadow-md shadow-cyan-950/40"
          >
            <Download className="w-4 h-4" />
            <span>Download .MD</span>
          </button>

          <button
            id="report-print-pdf-btn"
            onClick={handlePrintPDF}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#1e293b] hover:bg-slate-700 border border-slate-600/50 transition-all"
          >
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>Print / PDF</span>
          </button>

          <button
            id="report-rescan-btn"
            onClick={onTriggerScan}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 bg-[#0d131f] border border-[#1e293b] transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Rescan</span>
          </button>
        </div>
      </div>

      {/* Secret Shield Guarantee Notice */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/30 via-[#0d1624] to-[#0d1624] border border-emerald-500/30 flex items-start gap-3">
        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mt-0.5">
          <ShieldCheck className="w-4 h-4" />
        </div>
        <div className="flex-1">
          <h4 className="text-xs font-bold text-emerald-300">
            Secret Shield Compliance Guarantee
          </h4>
          <p className="text-[12px] text-slate-300 mt-0.5 leading-relaxed">
            This audit report is generated strictly with <strong>safe metadata</strong> (key identifiers, line numbers, entropy indices, and presence flags). Real passwords, API tokens, and credentials are intentionally masked with <code className="px-1 py-0.5 rounded bg-emerald-950/60 text-emerald-300 font-mono text-[11px]">[REDACTED]</code> to protect production security.
          </p>
        </div>
      </div>

      {/* Filter & View Controls */}
      <div className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Severity:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value as any)}
              className="px-2.5 py-1 rounded-lg text-xs bg-[#162033] border border-[#24334f] text-slate-200 outline-none focus:border-cyan-500"
            >
              <option value="all">All Severities ({issues.length})</option>
              <option value="critical-high">Critical & High Only</option>
              <option value="critical">Critical Only</option>
            </select>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includeResolved}
              onChange={(e) => setIncludeResolved(e.target.checked)}
              className="rounded border-slate-700 text-cyan-500 focus:ring-0 bg-[#162033]"
            />
            <span>Include Resolved Findings ({resolvedCount})</span>
          </label>

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includeDiffs}
              onChange={(e) => setIncludeDiffs(e.target.checked)}
              className="rounded border-slate-700 text-cyan-500 focus:ring-0 bg-[#162033]"
            />
            <span>Include Remediation Code Diffs</span>
          </label>
        </div>

        {/* View Mode Toggle: Formatted vs Raw Markdown */}
        <div className="flex items-center rounded-lg bg-[#141d2c] p-1 border border-[#24334c]">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'preview'
                ? 'bg-cyan-500/20 text-cyan-300 shadow-sm border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Formatted Audit
          </button>
          <button
            onClick={() => setActiveTab('markdown')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'markdown'
                ? 'bg-cyan-500/20 text-cyan-300 shadow-sm border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Raw Markdown
          </button>
        </div>
      </div>

      {activeTab === 'markdown' ? (
        /* Raw Markdown View */
        <div className="relative rounded-2xl bg-[#0a0f18] border border-[#1e293b] p-6 shadow-2xl">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1e293b]">
            <span className="text-xs font-mono text-slate-400">report.md ({markdownReport.split('\n').length} lines)</span>
            <button
              onClick={handleCopyMarkdown}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Raw</span>
            </button>
          </div>
          <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed max-h-[700px] overflow-y-auto pr-2">
            {markdownReport}
          </pre>
        </div>
      ) : (
        /* Formatted Audit View (Print & PDF Optimized) */
        <div id="printable-report" className="space-y-8">
          {/* Executive Overview Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-[#101726] to-[#0c111c] border border-[#1e293b] shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-[#1e293b]">
              <div>
                <span className="text-[11px] font-mono text-slate-400 block mb-1">PROJECT AUDIT TARGET</span>
                <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  {project?.name || 'Main Application Repository'}
                  <span className="px-2 py-0.5 text-xs rounded bg-[#162133] border border-[#263752] text-cyan-400 font-mono">
                    branch: {project?.branch || 'main'}
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Audit Timestamp: {generatedAt} • Engine Version: DriftLens v2.4
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block mb-0.5">HEALTH SCORE</span>
                  <div className="flex items-baseline justify-end gap-1">
                    <span
                      className={`text-3xl font-extrabold font-mono ${
                        (project?.healthScore ?? 0) >= 80
                          ? 'text-emerald-400'
                          : (project?.healthScore ?? 0) >= 65
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {project?.healthScore ?? 78}%
                    </span>
                  </div>
                </div>

                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${
                    (project?.healthScore ?? 0) >= 80
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : (project?.healthScore ?? 0) >= 65
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                  }`}
                >
                  <ShieldCheck className="w-8 h-8" />
                </div>
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
              <div className="p-3.5 rounded-xl bg-[#090d16] border border-[#1c2638]">
                <span className="text-[11px] text-slate-400 block mb-1">Missing Keys</span>
                <span className="text-xl font-bold font-mono text-rose-400">{missingIssues.length}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Absent in runtime envs</span>
              </div>
              <div className="p-3.5 rounded-xl bg-[#090d16] border border-[#1c2638]">
                <span className="text-[11px] text-slate-400 block mb-1">Orphaned Keys</span>
                <span className="text-xl font-bold font-mono text-amber-400">{orphanedIssues.length}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Defined but unused</span>
              </div>
              <div className="p-3.5 rounded-xl bg-[#090d16] border border-[#1c2638]">
                <span className="text-[11px] text-slate-400 block mb-1">Type Mismatches</span>
                <span className="text-xl font-bold font-mono text-purple-400">{mismatchIssues.length}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Format collisions</span>
              </div>
              <div className="p-3.5 rounded-xl bg-[#090d16] border border-[#1c2638]">
                <span className="text-[11px] text-slate-400 block mb-1">Masked Secrets</span>
                <span className="text-xl font-bold font-mono text-red-400">{exposedSecrets.length}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Flagged for rotation</span>
              </div>
            </div>
          </div>

          {/* Multi-Environment Parity Matrix Table */}
          <div className="rounded-2xl bg-[#0c121e] border border-[#1e293b] p-6 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Environment Parity & Variable Alignment
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#1e293b] text-slate-400">
                    <th className="py-2.5 px-3 font-semibold">Environment</th>
                    <th className="py-2.5 px-3 font-semibold">Tracked Variables</th>
                    <th className="py-2.5 px-3 font-semibold">Parity Health</th>
                    <th className="py-2.5 px-3 font-semibold">Missing In Env</th>
                    <th className="py-2.5 px-3 font-semibold">Orphaned In Env</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]/60">
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-200 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      Development (.env.development)
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {project?.environments?.development?.varsCount || 42} keys
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        HEALTHY (Baseline)
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">0</td>
                    <td className="py-3 px-3 font-mono text-amber-400">2</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-200 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      Staging (.env.staging)
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {project?.environments?.staging?.varsCount || 38} keys
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                        DRIFT DETECTED
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-rose-400">3</td>
                    <td className="py-3 px-3 font-mono text-amber-400">1</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-200 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-rose-400" />
                      Production (.env.production)
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {project?.environments?.production?.varsCount || 36} keys
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/20">
                        CRITICAL DRIFT
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-rose-400">4</td>
                    <td className="py-3 px-3 font-mono text-amber-400">1</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section: Missing Configuration Drifts */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-rose-400" />
                  Missing Configuration Drifts ({missingIssues.length})
                </h4>
                <p className="text-xs text-slate-400">
                  Critical keys referenced in application code but missing in Staging or Production.
                </p>
              </div>
            </div>

            {missingIssues.length === 0 ? (
              <div className="p-6 rounded-xl bg-[#0c121e] border border-[#1e293b] text-center text-xs text-slate-400">
                No missing configuration drifts match current filter.
              </div>
            ) : (
              <div className="space-y-3">
                {missingIssues.map((issue) => (
                  <div
                    key={issue.id}
                    className="p-5 rounded-xl bg-[#0c121e] border border-[#1e293b] hover:border-slate-700 transition-all space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <code className="text-sm font-bold font-mono text-cyan-300 bg-[#141d2c] px-2 py-0.5 rounded border border-[#24334c]">
                          {issue.keyOrTarget}
                        </code>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            issue.severity === 'critical'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {issue.severity}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">
                          {issue.filePath}:{issue.line}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {issue.status === 'resolved' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            RESOLVED
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/20">
                            UNRESOLVED ({issue.repeatCount}x)
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-[#090e17] p-3 rounded-lg border border-[#172336]">
                      <div>
                        <span className="text-[11px] font-semibold text-rose-300 block mb-0.5">
                          Runtime Problem & Impact:
                        </span>
                        <p className="text-slate-300 leading-relaxed">{issue.mindMapData.impact}</p>
                      </div>
                      <div>
                        <span className="text-[11px] font-semibold text-cyan-300 block mb-0.5">
                          Safe Action Directive:
                        </span>
                        <p className="text-slate-300 leading-relaxed">{issue.mindMapData.recommendedAction}</p>
                      </div>
                    </div>

                    {includeDiffs && issue.fixSuggestion && (
                      <div className="rounded-lg bg-[#070b12] border border-[#1a2538] p-3 space-y-1 font-mono text-[11px]">
                        <div className="text-slate-400 font-semibold mb-1 flex items-center justify-between">
                          <span>Target: {issue.fixSuggestion.targetFile}</span>
                          <span className="text-[10px] text-indigo-300">AI Remediation Patch</span>
                        </div>
                        <div className="text-rose-400 bg-rose-950/20 px-2 py-1 rounded">
                          - {issue.fixSuggestion.diffBefore}
                        </div>
                        <div className="text-emerald-400 bg-emerald-950/20 px-2 py-1 rounded">
                          + {issue.fixSuggestion.diffAfter}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section: Orphaned Configuration Drifts */}
          <div className="space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Orphaned Configuration Drifts ({orphanedIssues.length})
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {orphanedIssues.map((issue) => (
                <div
                  key={issue.id}
                  className="p-4 rounded-xl bg-[#0c121e] border border-[#1e293b] space-y-2.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <code className="font-bold font-mono text-amber-300 bg-[#162030] px-2 py-0.5 rounded">
                      {issue.keyOrTarget}
                    </code>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      ORPHANED
                    </span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{issue.mindMapData.problem}</p>
                  <div className="text-[11px] text-slate-400 bg-[#080d17] p-2 rounded border border-[#1a2538]">
                    <span className="text-slate-300 font-semibold">Remediation: </span>
                    {issue.mindMapData.recommendedAction}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Type & Value Inconsistencies */}
          <div className="space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              Type & Schema Inconsistencies ({mismatchIssues.length})
            </h4>

            <div className="space-y-3">
              {mismatchIssues.map((issue) => (
                <div
                  key={issue.id}
                  className="p-4 rounded-xl bg-[#0c121e] border border-[#1e293b] space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <code className="font-bold font-mono text-purple-300 bg-[#1a1c30] px-2 py-0.5 rounded border border-purple-500/30">
                        {issue.keyOrTarget}
                      </code>
                      <span className="text-slate-400 font-mono text-[11px]">{issue.filePath}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      TYPE MISMATCH
                    </span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{issue.mindMapData.evidence}</p>
                  <p className="text-slate-400 text-[11px]">
                    <strong className="text-purple-300">Action:</strong> {issue.mindMapData.recommendedAction}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Secret Shield Audit */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-red-400" />
                Secret Shield Audit Findings ({secrets.length})
              </h4>
              <span className="text-[11px] text-emerald-400 font-mono">
                100% Sanitized Metadata
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-[#1e293b] bg-[#0b101b]">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#1e293b] text-slate-400 bg-[#0d1422]">
                    <th className="py-2.5 px-3 font-semibold">Key Identifier</th>
                    <th className="py-2.5 px-3 font-semibold">Location</th>
                    <th className="py-2.5 px-3 font-semibold">Entropy</th>
                    <th className="py-2.5 px-3 font-semibold">Audit Status</th>
                    <th className="py-2.5 px-3 font-semibold">Remediation Protocol</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]/60">
                  {secrets.map((s) => (
                    <tr key={s.id} className="hover:bg-[#111827]">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-200">
                        {s.keyName}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-400">
                        {s.location}:{s.line}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-300">
                        {s.entropy} H
                      </td>
                      <td className="py-2.5 px-3">
                        {s.status === 'exposed' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                            EXPOSED
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            SECURED
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 max-w-xs truncate">
                        {s.remediationRecommendation}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Footer Note */}
          <div className="pt-6 border-t border-[#1e293b] text-center text-xs text-slate-500">
            Report generated by DriftLens • Project Configuration & Environment Drift Audit Engine
          </div>
        </div>
      )}
    </div>
  );
};
