import React, { useState } from 'react';
import {
  Network,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Folder,
  FileCode,
  ArrowRight,
  Sparkles,
  GitFork,
  Filter,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { ProjectConfig, DriftIssue, ModuleNode } from '../types';
import { NavRoute } from './Sidebar';

interface HealthMapViewProps {
  project: ProjectConfig | null;
  issues: DriftIssue[];
  onNavigate: (route: NavRoute) => void;
  onSelectIssueForMindMap?: (issue: DriftIssue) => void;
}

export const HealthMapView: React.FC<HealthMapViewProps> = ({
  project,
  issues,
  onNavigate,
  onSelectIssueForMindMap,
}) => {
  const [selectedModule, setSelectedModule] = useState<ModuleNode | null>(
    project?.modules?.[0] || null
  );
  const [envFilter, setEnvFilter] = useState<'all' | 'dev' | 'staging' | 'prod'>('all');

  const modules = project?.modules || [];

  // Filter issues belonging to selected module
  const moduleIssues = selectedModule
    ? issues.filter((i) => i.filePath.startsWith(selectedModule.path))
    : [];

  const getStatusColor = (status: 'healthy' | 'warnings' | 'critical') => {
    if (status === 'healthy') return 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300';
    if (status === 'warnings') return 'border-amber-500/40 bg-amber-950/20 text-amber-300';
    return 'border-rose-500/40 bg-rose-950/20 text-rose-300';
  };

  const getStatusDot = (status: 'healthy' | 'warnings' | 'critical') => {
    if (status === 'healthy') return 'bg-emerald-400';
    if (status === 'warnings') return 'bg-amber-400';
    return 'bg-rose-400';
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Network className="w-6 h-6 text-cyan-400" />
            Codebase & Configuration Health Map
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Visual topology of module architecture, environment configuration parity, and active drift hotspots.
          </p>
        </div>

        {/* Environment Filter */}
        <div className="flex items-center gap-2 bg-[#111827] p-1 rounded-xl border border-[#1e293b]">
          <span className="text-[11px] font-semibold text-slate-400 px-2 flex items-center gap-1">
            <Filter className="w-3 h-3" /> View:
          </span>
          {(['all', 'dev', 'staging', 'prod'] as const).map((env) => (
            <button
              key={env}
              onClick={() => setEnvFilter(env)}
              className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-colors ${
                envFilter === env
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {env === 'all' ? 'All Environments' : env}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Cards: Overall Health, Total Checked, Drift Count */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Overall Health Score */}
        <div className="p-5 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-2">
          <span className="text-xs font-medium text-slate-400 block">Overall Health Score</span>
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-extrabold font-mono text-cyan-400">{project?.healthScore ?? 78}%</span>
            <span className="text-xs text-slate-400">
              {(project?.healthScore ?? 78) >= 80 ? 'Grade A-' : 'Grade B (Drift Detected)'}
            </span>
          </div>
          <div className="w-full bg-[#1e293b] rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                (project?.healthScore ?? 78) >= 80
                  ? 'bg-emerald-400'
                  : (project?.healthScore ?? 78) >= 65
                  ? 'bg-amber-400'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${project?.healthScore ?? 78}%` }}
            />
          </div>
        </div>

        {/* Total Checked Variables */}
        <div className="p-5 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-2">
          <span className="text-xs font-medium text-slate-400 block">Total Checked Variables</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-white">142</span>
            <span className="text-xs text-slate-400">keys indexed</span>
          </div>
          <p className="text-[11px] text-slate-400">Across 3 environments & 384 project files</p>
        </div>

        {/* Drift Count */}
        <div
          onClick={() => onNavigate('issues')}
          className="p-5 rounded-2xl bg-[#111827] border border-[#1e293b] hover:border-rose-500/40 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Active Drift Count</span>
            <AlertTriangle className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-rose-400">
              {issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored').length}
            </span>
            <span className="text-xs text-rose-400/80">detected differences</span>
          </div>
          <p className="text-[11px] text-slate-400">Missing, orphaned, and type collisions</p>
        </div>
      </div>

      {/* Visual Environment Comparison */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
          <span>Visual Environment Comparison</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Development */}
          <div className="p-5 rounded-2xl bg-[#0e1422] border border-emerald-500/30 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white">Development</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Good
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold font-mono text-emerald-400">
                {project?.environments?.development?.varsCount || 42}
              </span>
              <span className="text-xs text-slate-400">keys declared (.env.development)</span>
            </div>
            <p className="text-xs text-slate-400">
              Baseline source environment. All code references successfully resolved locally.
            </p>
            <div className="pt-2 border-t border-[#1e293b]/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Drift Score: 0%</span>
              <span className="text-emerald-400 font-semibold">100% Parity</span>
            </div>
          </div>

          {/* Staging */}
          <div className="p-5 rounded-2xl bg-[#0e1422] border border-amber-500/30 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white">Staging</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Warning
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold font-mono text-amber-400">
                {project?.environments?.staging?.varsCount || 38}
              </span>
              <span className="text-xs text-slate-400">keys declared (.env.staging)</span>
            </div>
            <p className="text-xs text-slate-400">
              Warning status due to orphaned configuration keys and minor schema differences.
            </p>
            <div className="pt-2 border-t border-[#1e293b]/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Drift Score: 18%</span>
              <span className="text-amber-400 font-semibold">82% Parity</span>
            </div>
          </div>

          {/* Production */}
          <div className="p-5 rounded-2xl bg-[#0e1422] border border-rose-500/40 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white">Production</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1.5">
                <XCircle className="w-3.5 h-3.5" />
                Critical
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold font-mono text-rose-400">
                {project?.environments?.production?.varsCount || 36}
              </span>
              <span className="text-xs text-slate-400">keys declared (.env.production)</span>
            </div>
            <p className="text-xs text-slate-400">
              Critical drift alert: Missing PAYMENT_KEY and type mismatch crash on SESSION_TIMEOUT_SECONDS.
            </p>
            <div className="pt-2 border-t border-[#1e293b]/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Drift Score: 36%</span>
              <span className="text-rose-400 font-semibold">64% Parity</span>
            </div>
          </div>
        </div>
      </div>

      {/* Legend Bar */}
      <div className="p-3.5 rounded-xl bg-[#101726] border border-[#1e293b] flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-5">
          <span className="text-slate-400 font-medium">Health Status:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="text-slate-300">Healthy (No Drift)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="text-slate-300">Warnings (Orphaned / Non-breaking)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-pulse" />
            <span className="text-slate-300">Critical (Missing Env / Secret / Type Crash)</span>
          </div>
        </div>

        <span className="text-slate-500 font-mono text-[11px]">Click any module node to inspect issues</span>
      </div>

      {/* Interactive Visual Health Map Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Modules Tree / Grid (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {modules.map((mod) => {
              const isSelected = selectedModule?.id === mod.id;
              const statusColor = getStatusColor(mod.status);
              const dotColor = getStatusDot(mod.status);

              return (
                <div
                  key={mod.id}
                  onClick={() => setSelectedModule(mod)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer select-none ${
                    isSelected
                      ? 'border-cyan-400 bg-[#131d2e] shadow-xl shadow-cyan-950/40 ring-1 ring-cyan-400/40'
                      : 'border-[#1e293b] bg-[#111827] hover:border-slate-600 hover:bg-[#121b2b]'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-xl bg-[#172235] text-cyan-400">
                        <Folder className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white tracking-tight">{mod.name}</h4>
                        <span className="text-[11px] font-mono text-slate-400">{mod.path}</span>
                      </div>
                    </div>

                    <span className={`w-2.5 h-2.5 rounded-full ${dotColor}`} />
                  </div>

                  <div className="flex items-end justify-between pt-2 border-t border-[#1e293b]/70">
                    <div>
                      <span className="text-[10px] uppercase font-mono text-slate-400 block">Health Index</span>
                      <span
                        className={`text-xl font-bold font-mono ${
                          mod.healthScore >= 80
                            ? 'text-emerald-400'
                            : mod.healthScore >= 60
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {mod.healthScore}%
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] uppercase font-mono text-slate-400 block">Drift Issues</span>
                      <span
                        className={`text-xs font-mono font-semibold px-2 py-0.5 rounded border ${statusColor}`}
                      >
                        {mod.issuesCount} {mod.issuesCount === 1 ? 'issue' : 'issues'}
                      </span>
                    </div>
                  </div>

                  {/* Environment presence mini badges */}
                  <div className="mt-3 pt-2.5 border-t border-[#1e293b]/50 flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span className="text-emerald-400">DEV: OK</span>
                    <span className={mod.status === 'critical' ? 'text-amber-400' : 'text-emerald-400'}>
                      STAGING: {mod.status === 'critical' ? 'WARN' : 'OK'}
                    </span>
                    <span className={mod.status === 'critical' ? 'text-rose-400' : 'text-emerald-400'}>
                      PROD: {mod.status === 'critical' ? 'DRIFT' : 'OK'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Codebase Tree Visual Blueprint */}
          <div className="p-5 rounded-2xl bg-[#090e17] border border-[#1e293b] space-y-3 font-mono text-xs">
            <span className="text-slate-400 font-semibold text-[11px] flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              Project File Hierarchy & Drift Annotations:
            </span>

            <div className="space-y-1.5 text-slate-300 text-[11px] bg-[#0c121e] p-3.5 rounded-xl border border-[#1b2538]">
              <div className="text-cyan-400 font-bold">project-root/</div>
              <div className="pl-4 text-slate-400">├── config/</div>
              <div className="pl-8 flex items-center justify-between text-slate-300">
                <span>├── .env.development</span>
                <span className="text-[10px] text-emerald-400 font-bold">[Dev Baseline]</span>
              </div>
              <div className="pl-8 flex items-center justify-between text-amber-300">
                <span>├── .env.staging</span>
                <span className="text-[10px] text-amber-400 font-bold">[Missing 4 keys]</span>
              </div>
              <div className="pl-8 flex items-center justify-between text-rose-300">
                <span>└── .env.production</span>
                <span className="text-[10px] text-rose-400 font-bold">[Critical Drift - Stripe Key]</span>
              </div>

              <div className="pl-4 text-slate-400">├── src/</div>
              <div className="pl-8 flex items-center justify-between text-rose-300">
                <span>├── services/billing.ts:48</span>
                <span className="text-[10px] text-rose-400 font-bold">[Missing in Prod + Secret Exposed]</span>
              </div>
              <div className="pl-8 flex items-center justify-between text-purple-300">
                <span>├── middleware/auth.ts:34</span>
                <span className="text-[10px] text-purple-400 font-bold">[Type Mismatch: number vs '24h']</span>
              </div>
              <div className="pl-8 flex items-center justify-between text-amber-300">
                <span>├── utils/deprecations.ts</span>
                <span className="text-[10px] text-amber-400 font-bold">[Orphaned Module - 0 Imports]</span>
              </div>
              <div className="pl-8 flex items-center justify-between text-emerald-400">
                <span>└── components/Dashboard.tsx</span>
                <span className="text-[10px] text-emerald-400 font-bold">[Healthy]</span>
              </div>
            </div>
          </div>
        </div>

        {/* Module Inspector Drawer (1 Col) */}
        <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] flex flex-col justify-between space-y-6">
          {selectedModule ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-3">
                <div>
                  <span className="text-[10px] font-mono uppercase text-cyan-400 font-semibold block">
                    Module Inspector
                  </span>
                  <h3 className="text-base font-bold text-white tracking-tight">{selectedModule.name}</h3>
                </div>
                <span
                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${getStatusColor(
                    selectedModule.status
                  )}`}
                >
                  {selectedModule.healthScore}%
                </span>
              </div>

              <div className="space-y-1 text-xs">
                <span className="text-slate-400 block text-[11px]">Module Path:</span>
                <span className="font-mono text-cyan-300 bg-[#0c121e] px-2.5 py-1 rounded border border-[#1e293b] block truncate">
                  {selectedModule.path}
                </span>
              </div>

              {/* Parity Status Across Envs */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-300 block">Environment Parity:</span>
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex items-center justify-between p-2 rounded bg-[#0e1422] border border-[#1e293b]">
                    <span className="text-slate-300">Development:</span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 100% Synced
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#0e1422] border border-amber-900/40">
                    <span className="text-slate-300">Staging:</span>
                    <span className="text-amber-400 font-semibold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> Incomplete Keys
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#0e1422] border border-rose-900/40">
                    <span className="text-slate-300">Production:</span>
                    <span className="text-rose-400 font-semibold flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" /> Runtime Drift Alert
                    </span>
                  </div>
                </div>
              </div>

              {/* Detected Issues in this module */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">Issues in Module:</span>
                  <span className="text-xs font-mono text-slate-400">{moduleIssues.length} found</span>
                </div>

                {moduleIssues.length === 0 ? (
                  <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-center text-xs text-emerald-300">
                    No active drift detected in this module. Configuration matches across all environments.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {moduleIssues.map((issue) => (
                      <div
                        key={issue.id}
                        className="p-3 rounded-xl bg-[#0e1422] border border-[#1e293b] hover:border-slate-600 transition-colors space-y-1.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-xs font-bold text-white truncate">{issue.title}</span>
                          <span
                            className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded ${
                              issue.severity === 'critical'
                                ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                : 'bg-amber-950 text-amber-300 border border-amber-800'
                            }`}
                          >
                            {issue.severity}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-2">{issue.description}</p>
                        <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-slate-500">
                          <span>Line {issue.line}</span>
                          <button
                            onClick={() => {
                              if (onSelectIssueForMindMap) onSelectIssueForMindMap(issue);
                              onNavigate('mind-map');
                            }}
                            className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-sans"
                          >
                            Mind Map <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-xs">
              Select any module in the map to inspect its environment parity.
            </div>
          )}

          <div className="pt-4 border-t border-[#1e293b] flex gap-2">
            <button
              onClick={() => onNavigate('mind-map')}
              className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/40 transition-colors flex items-center justify-center gap-1.5"
            >
              <GitFork className="w-3.5 h-3.5" />
              <span>Drift Mind Map</span>
            </button>
            <button
              onClick={() => onNavigate('fixes')}
              className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 transition-colors flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Fixes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
