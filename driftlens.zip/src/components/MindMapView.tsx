import React, { useState } from 'react';
import {
  GitFork,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Zap,
  Sparkles,
  ArrowRight,
  Code2,
  FileCode,
  ShieldAlert,
  Server,
  Terminal,
  Activity,
  ChevronRight,
  Info,
  Maximize2,
} from 'lucide-react';
import { DriftIssue, ProjectConfig } from '../types';
import { NavRoute } from './Sidebar';

interface MindMapViewProps {
  project: ProjectConfig | null;
  issues: DriftIssue[];
  selectedIssueId?: string;
  onNavigate: (route: NavRoute) => void;
  onSelectIssueForFix?: (issue: DriftIssue) => void;
  onApplyFix: (issueId: string) => void;
}

export const MindMapView: React.FC<MindMapViewProps> = ({
  project,
  issues,
  selectedIssueId,
  onNavigate,
  onSelectIssueForFix,
  onApplyFix,
}) => {
  const [activeIssue, setActiveIssue] = useState<DriftIssue>(
    issues.find((i) => i.id === selectedIssueId) || issues[0]
  );
  const [activeTabStep, setActiveTabStep] = useState<'problem' | 'evidence' | 'impact' | 'action'>('problem');

  const getDriftIcon = (type: string) => {
    switch (type) {
      case 'missing':
        return <XCircle className="w-3.5 h-3.5 text-rose-400" />;
      case 'orphaned':
        return <HelpCircle className="w-3.5 h-3.5 text-amber-400" />;
      case 'type_mismatch':
        return <Zap className="w-3.5 h-3.5 text-purple-400" />;
      default:
        return <AlertTriangle className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              SIGNATURE FEATURE
            </span>
            <span className="text-xs text-slate-400">• Interactive Topological Analysis</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 mt-1">
            <GitFork className="w-6 h-6 text-cyan-400" />
            Drift Mind Map & Root-Cause Explorer
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Visual chain of custody connecting: Project ➔ Environment ➔ Detected Drift ➔ Affected Key/File ➔ Exact Code Location.
          </p>
        </div>

        <button
          onClick={() => {
            if (onSelectIssueForFix && activeIssue) onSelectIssueForFix(activeIssue);
            onNavigate('fixes');
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 shadow-md transition-all active:scale-95"
        >
          <Sparkles className="w-4 h-4 text-indigo-200" />
          <span>Apply AI Fix for Active Issue</span>
        </button>
      </div>

      {/* Visual Interactive Mind Map Diagram (The Signature Visual Feature) */}
      <div className="p-6 rounded-2xl bg-[#0d131f] border border-cyan-500/40 shadow-2xl relative overflow-hidden space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1e293b] pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
                Interactive Mind Map Topology
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Live configuration connection graph. Click any environment node or issue pill to inspect details in the side panel.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" /> Dev (100% Parity)
            </span>
            <span className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2 h-2 rounded-full bg-amber-400" /> Staging (Warning)
            </span>
            <span className="flex items-center gap-1.5 text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" /> Prod (Critical)
            </span>
          </div>
        </div>

        {/* The Mind Map Graph Canvas */}
        <div className="py-4 px-2 space-y-8">
          {/* Level 1: Central Node */}
          <div className="flex justify-center">
            <div className="relative group">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-600 opacity-70 blur-sm group-hover:opacity-100 transition-all duration-500" />
              <div className="relative px-8 py-4 rounded-2xl bg-[#10192a] border border-cyan-400/50 shadow-2xl flex items-center gap-3.5">
                <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  <Server className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-cyan-400 font-bold block">
                    Central Node • Codebase
                  </span>
                  <h3 className="text-base font-extrabold text-white tracking-tight">
                    {project?.name || 'DriftLens Demo App'}
                  </h3>
                  <span className="text-[11px] font-mono text-slate-400">384 Source Files • 142 Config References</span>
                </div>
              </div>
            </div>
          </div>

          {/* Level 2: 3 Environment Branches */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
            {/* Development Branch */}
            <div className="rounded-2xl bg-[#090d16] border border-emerald-500/40 p-5 space-y-3.5 shadow-lg relative group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
                  <h4 className="text-sm font-bold text-white tracking-tight">🟢 Development Environment</h4>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">
                  Healthy
                </span>
              </div>
              <div className="text-xs text-slate-400 space-y-1">
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Status:</span>
                  <span className="text-emerald-400 font-bold">Good (0 Drift)</span>
                </div>
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Declared:</span>
                  <span className="text-slate-300">42 variables</span>
                </div>
              </div>
              {/* Associated Config Keys */}
              <div className="space-y-1.5 pt-2 border-t border-[#1e293b]">
                <span className="text-[10px] font-mono uppercase text-slate-400 block font-semibold">
                  Associated Configuration Keys:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {['DATABASE_URL', 'PORT', 'AUTH_SECRET', 'PAYMENT_KEY', 'REDIS_HOST'].map((key) => (
                    <span
                      key={key}
                      className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#111827] text-slate-300 border border-emerald-800/40"
                    >
                      {key}
                    </span>
                  ))}
                </div>
              </div>
              {/* Problem Indicators */}
              <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/20 flex items-center gap-2 text-xs text-emerald-400 font-mono">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                <span>0 problem indicators. 100% parity.</span>
              </div>
            </div>

            {/* Staging Branch */}
            <div className="rounded-2xl bg-[#090d16] border border-amber-500/40 p-5 space-y-3.5 shadow-lg relative group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-amber-400 shadow-sm shadow-amber-400" />
                  <h4 className="text-sm font-bold text-white tracking-tight">🟡 Staging Environment</h4>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/60 text-amber-300 border border-amber-500/30">
                  Warning
                </span>
              </div>
              <div className="text-xs text-slate-400 space-y-1">
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Status:</span>
                  <span className="text-amber-400 font-bold">Warning (18% Drift)</span>
                </div>
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Declared:</span>
                  <span className="text-slate-300">38 variables</span>
                </div>
              </div>
              {/* Associated Config Keys */}
              <div className="space-y-1.5 pt-2 border-t border-[#1e293b]">
                <span className="text-[10px] font-mono uppercase text-slate-400 block font-semibold">
                  Associated Configuration Keys:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <span
                    onClick={() => {
                      const found = issues.find((i) => i.keyOrTarget.includes('LEGACY'));
                      if (found) setActiveIssue(found);
                    }}
                    className="px-2 py-0.5 rounded text-[11px] font-mono bg-amber-950/40 text-amber-300 border border-amber-500/50 cursor-pointer hover:bg-amber-900/60 transition-colors"
                  >
                    LEGACY_API_URL ⚠️
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#111827] text-slate-300 border border-[#1e293b]">
                    DATABASE_URL
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#111827] text-slate-300 border border-[#1e293b]">
                    AUTH_SECRET
                  </span>
                </div>
              </div>
              {/* Problem Indicators */}
              <div
                onClick={() => {
                  const found = issues.find((i) => i.type === 'orphaned');
                  if (found) setActiveIssue(found);
                }}
                className="p-2.5 rounded-xl bg-amber-950/20 border border-amber-500/30 flex items-center justify-between text-xs text-amber-300 font-mono cursor-pointer hover:bg-amber-950/40 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span>1 Orphaned Key (Unreferenced)</span>
                </div>
                <span className="text-[10px] underline">Inspect</span>
              </div>
            </div>

            {/* Production Branch */}
            <div className="rounded-2xl bg-[#090d16] border border-rose-500/50 p-5 space-y-3.5 shadow-lg relative group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-rose-400 shadow-sm shadow-rose-400 animate-pulse" />
                  <h4 className="text-sm font-bold text-white tracking-tight">🔴 Production Environment</h4>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950/60 text-rose-300 border border-rose-500/40">
                  Critical
                </span>
              </div>
              <div className="text-xs text-slate-400 space-y-1">
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Status:</span>
                  <span className="text-rose-400 font-bold">Critical (36% Drift)</span>
                </div>
                <div className="flex justify-between font-mono text-[11px]">
                  <span>Declared:</span>
                  <span className="text-slate-300">36 variables</span>
                </div>
              </div>
              {/* Associated Config Keys */}
              <div className="space-y-1.5 pt-2 border-t border-[#1e293b]">
                <span className="text-[10px] font-mono uppercase text-slate-400 block font-semibold">
                  Associated Configuration Keys:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <span
                    onClick={() => {
                      const found = issues.find((i) => i.keyOrTarget.includes('PAYMENT'));
                      if (found) setActiveIssue(found);
                    }}
                    className="px-2 py-0.5 rounded text-[11px] font-mono bg-rose-950/60 text-rose-300 border border-rose-500/60 font-bold cursor-pointer hover:bg-rose-900/80 transition-colors animate-pulse"
                  >
                    PAYMENT_KEY ❌
                  </span>
                  <span
                    onClick={() => {
                      const found = issues.find((i) => i.type === 'type_mismatch');
                      if (found) setActiveIssue(found);
                    }}
                    className="px-2 py-0.5 rounded text-[11px] font-mono bg-purple-950/60 text-purple-300 border border-purple-500/50 cursor-pointer hover:bg-purple-900/60 transition-colors"
                  >
                    SESSION_TIMEOUT ⚡
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#111827] text-slate-300 border border-[#1e293b]">
                    DATABASE_URL
                  </span>
                </div>
              </div>
              {/* Problem Indicators */}
              <div
                onClick={() => {
                  const found = issues.find((i) => i.type === 'missing');
                  if (found) setActiveIssue(found);
                }}
                className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/40 flex items-center justify-between text-xs text-rose-300 font-mono cursor-pointer hover:bg-rose-950/50 transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <XCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                  <span>2 Critical Drift Issues</span>
                </div>
                <span className="text-[10px] underline">Inspect</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Mind Map Graph Explorer (Left) & 4-Step Walkthrough (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Interactive Topological Chain & Issue Selector */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-3">
            <span className="text-xs font-semibold text-slate-300 block">
              Select Detected Drift Chain to Explore:
            </span>

            <div className="space-y-2 max-h-[580px] overflow-y-auto pr-1">
              {issues.map((issue) => {
                const isSelected = activeIssue?.id === issue.id;
                const isResolved = issue.status === 'resolved';

                return (
                  <div
                    key={issue.id}
                    onClick={() => {
                      setActiveIssue(issue);
                      setActiveTabStep('problem');
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      isSelected
                        ? 'bg-[#141d2e] border-cyan-400 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-400/40'
                        : isResolved
                        ? 'bg-[#0d131f]/50 border-emerald-900/30 opacity-70'
                        : 'bg-[#0e1422] border-[#1e293b] hover:border-slate-600'
                    }`}
                  >
                    {/* Visual Chain Trail */}
                    <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 mb-1.5 truncate">
                      <span className="text-slate-300 truncate">{project?.name || 'Project'}</span>
                      <ChevronRight className="w-3 h-3 text-slate-600 flex-shrink-0" />
                      <span className={issue.affectedEnvironments.production ? 'text-emerald-400' : 'text-rose-400'}>
                        {issue.affectedEnvironments.production ? 'Dev/Stage' : 'Prod'}
                      </span>
                      <ChevronRight className="w-3 h-3 text-slate-600 flex-shrink-0" />
                      <span className="uppercase text-cyan-400 font-bold">{issue.type.replace('_', ' ')}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white truncate">{issue.keyOrTarget}</span>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {getDriftIcon(issue.type)}
                        <span
                          className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded ${
                            issue.severity === 'critical'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {issue.severity}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] font-mono text-slate-500 mt-1 flex items-center justify-between">
                      <span className="truncate">{issue.filePath}:{issue.line}</span>
                      {isResolved && <span className="text-emerald-400 text-[10px]">Resolved</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (7 Cols): The 4-Step Walkthrough Panel */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] shadow-xl space-y-6">
            {/* Visual Mind Map Flow Breadcrumb */}
            <div className="p-4 rounded-xl bg-[#090d15] border border-cyan-500/30 space-y-2">
              <span className="text-[10px] font-mono uppercase text-cyan-400 font-bold tracking-wider block">
                Topological Connection Path
              </span>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                <span className="px-2 py-1 rounded bg-[#131b2a] border border-[#233148] text-slate-200">
                  {project?.name || 'Nexus Core'}
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                <span className="px-2 py-1 rounded bg-[#131b2a] border border-[#233148] text-amber-300">
                  Production / Staging
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                <span className="px-2 py-1 rounded bg-[#131b2a] border border-rose-900/50 text-rose-300">
                  {activeIssue.type.toUpperCase()} DRIFT
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                <span className="px-2 py-1 rounded bg-cyan-950/60 border border-cyan-600/50 text-cyan-300 font-bold">
                  {activeIssue.keyOrTarget}
                </span>
              </div>
            </div>

            {/* 4-Step Walkthrough Navigation Tabs */}
            <div className="grid grid-cols-4 gap-2 border-b border-[#1e293b] pb-3">
              {[
                { id: 'problem', label: '1. Problem', color: 'text-cyan-400' },
                { id: 'evidence', label: '2. Evidence', color: 'text-amber-400' },
                { id: 'impact', label: '3. Impact', color: 'text-rose-400' },
                { id: 'action', label: '4. Action', color: 'text-emerald-400' },
              ].map((step) => {
                const isActive = activeTabStep === step.id;
                return (
                  <button
                    key={step.id}
                    onClick={() => setActiveTabStep(step.id as any)}
                    className={`py-2 px-1 rounded-xl text-xs font-semibold text-center transition-all ${
                      isActive
                        ? 'bg-[#1b263b] text-white border border-cyan-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-[#121927]'
                    }`}
                  >
                    <span className={step.color}>{step.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Step Content Area */}
            <div className="min-h-[260px]">
              {/* Step 1: Problem */}
              {activeTabStep === 'problem' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-cyan-400 text-sm font-bold">
                    <Info className="w-4 h-4" />
                    <span>The Underlying Anomaly</span>
                  </div>
                  <p className="text-sm text-slate-200 leading-relaxed bg-[#0c121e] p-4 rounded-xl border border-[#1e293b]">
                    {activeIssue.mindMapData.problem}
                  </p>

                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[#0e1422] border border-[#1e293b]">
                      <span className="text-slate-500 block text-[10px]">Target Key / File:</span>
                      <span className="text-cyan-300 font-bold">{activeIssue.keyOrTarget}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-[#0e1422] border border-[#1e293b]">
                      <span className="text-slate-500 block text-[10px]">Severity Level:</span>
                      <span className="text-rose-400 uppercase font-bold">{activeIssue.severity}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Evidence */}
              {activeTabStep === 'evidence' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-amber-400 text-sm font-bold">
                    <Code2 className="w-4 h-4" />
                    <span>Code Call Site & AST Evidence</span>
                  </div>
                  <p className="text-xs text-slate-300">{activeIssue.mindMapData.evidence}</p>

                  <div className="rounded-xl bg-[#080c14] border border-[#1e293b] overflow-hidden font-mono text-xs">
                    <div className="px-3 py-1.5 bg-[#0e1422] border-b border-[#1e293b] flex items-center justify-between text-slate-400 text-[11px]">
                      <span>{activeIssue.filePath}:{activeIssue.line}</span>
                      <span className="text-amber-400">AST Node Match</span>
                    </div>
                    <pre className="p-3 text-[11px] text-slate-300 overflow-x-auto leading-relaxed">
                      {activeIssue.codeSnippet.surroundingContext || activeIssue.codeSnippet.before}
                    </pre>
                  </div>
                </div>
              )}

              {/* Step 3: Impact */}
              {activeTabStep === 'impact' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-rose-400 text-sm font-bold">
                    <ShieldAlert className="w-4 h-4" />
                    <span>Production & Staging Blast Radius</span>
                  </div>
                  <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/30 text-xs text-rose-200 leading-relaxed">
                    {activeIssue.mindMapData.impact}
                  </div>

                  <div className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] space-y-2">
                    <span className="text-xs font-semibold text-slate-300 block">Failure Mechanism:</span>
                    <ul className="text-xs text-slate-400 space-y-1.5 list-disc pl-4">
                      <li>Occurs during deployment container spin-up or runtime request execution.</li>
                      <li>Not caught by standard local unit tests because local `.env.development` has the variable.</li>
                      <li>Causes silent degradation or explicit runtime exceptions for end users.</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Step 4: Recommended Action */}
              {activeTabStep === 'action' && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Step-by-Step Remediation Plan</span>
                  </div>
                  <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-xs text-emerald-200 leading-relaxed font-mono">
                    {activeIssue.mindMapData.recommendedAction}
                  </div>

                  <div className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] space-y-3">
                    <span className="text-xs font-semibold text-slate-300 block">Automated Fix Options:</span>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => {
                          if (onSelectIssueForFix) onSelectIssueForFix(activeIssue);
                          onNavigate('fixes');
                        }}
                        className="flex-1 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 transition-all shadow-md flex items-center justify-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Open Diff in AI Fix View</span>
                      </button>

                      {activeIssue.status !== 'resolved' && (
                        <button
                          onClick={() => onApplyFix(activeIssue.id)}
                          className="px-4 py-2.5 rounded-xl text-xs font-semibold text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 transition-colors"
                        >
                          Mark As Resolved
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Step Walkthrough Footer Controls */}
            <div className="pt-4 border-t border-[#1e293b] flex items-center justify-between">
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <span>Selected:</span>
                <span className="text-slate-300 font-mono">{activeIssue.title}</span>
              </div>

              <div className="flex items-center gap-2">
                {activeTabStep !== 'action' ? (
                  <button
                    onClick={() => {
                      if (activeTabStep === 'problem') setActiveTabStep('evidence');
                      else if (activeTabStep === 'evidence') setActiveTabStep('impact');
                      else if (activeTabStep === 'impact') setActiveTabStep('action');
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-200 bg-[#1e293b] hover:bg-slate-700 transition-colors flex items-center gap-1.5"
                  >
                    <span>Next Step</span>
                    <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      if (onSelectIssueForFix) onSelectIssueForFix(activeIssue);
                      onNavigate('fixes');
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 transition-all flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Apply Fix</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
