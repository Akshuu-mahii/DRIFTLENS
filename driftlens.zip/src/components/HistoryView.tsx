import React, { useState } from 'react';
import {
  History,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Download,
  Calendar,
  Layers,
  ChevronDown,
  ChevronUp,
  Terminal,
} from 'lucide-react';
import { ScanRun } from '../types';

interface HistoryViewProps {
  history: ScanRun[];
  onTriggerNewScan: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onTriggerNewScan,
}) => {
  const [expandedScanId, setExpandedScanId] = useState<string | null>(history[0]?.id || null);

  const toggleExpand = (id: string) => {
    setExpandedScanId((prev) => (prev === id ? null : id));
  };

  const handleExportAudit = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `driftlens-audit-history-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              AUDIT TRAIL & EVOLUTION
            </span>
            <span className="text-xs text-slate-400">• Persistent Delta Tracking</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 mt-1">
            <History className="w-6 h-6 text-cyan-400" />
            Drift History & Longitudinal Parity Tracking
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Tracks issues as New, Still Unresolved, or Resolved across successive scans and release branches.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportAudit}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-[#1e293b] hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export Audit Report</span>
          </button>
          <button
            onClick={onTriggerNewScan}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-md transition-all active:scale-95"
          >
            <Clock className="w-4 h-4" />
            <span>Trigger New Scan</span>
          </button>
        </div>
      </div>

      {/* Health Trend Progression Metrics */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-[#101726] to-[#0d131f] border border-[#1e293b] space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            Health Score Trajectory Across Runs:
          </span>
          <span className="text-xs font-mono text-emerald-400 font-semibold">+6% Improvement Since Baseline</span>
        </div>

        {/* Visual score pills */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {history.slice(0, 3).map((scan, idx) => (
            <div
              key={scan.id}
              className="p-4 rounded-xl bg-[#090d16] border border-[#1e293b] space-y-2 font-mono text-xs"
            >
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span>Run #{history.length - idx}</span>
                <span>{scan.timestamp.slice(5, 16)}</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-extrabold text-white">{scan.healthScore}%</span>
                {scan.delta.scoreChange > 0 && (
                  <span className="text-emerald-400 text-xs font-semibold">+{scan.delta.scoreChange}%</span>
                )}
              </div>
              <div className="text-[11px] text-slate-400 font-sans">
                {scan.stats.resolvedCount > 0 ? (
                  <span className="text-emerald-300">{scan.stats.resolvedCount} issues resolved</span>
                ) : (
                  <span>Initial baseline audit</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* History Timeline Runs List */}
      <div className="space-y-4">
        <span className="text-xs font-semibold text-slate-300 block">Scan Run History ({history.length} runs):</span>

        {history.map((run, idx) => {
          const isExpanded = expandedScanId === run.id;

          return (
            <div
              key={run.id}
              className="rounded-2xl bg-[#111827] border border-[#1e293b] overflow-hidden transition-all shadow-lg hover:border-slate-600"
            >
              {/* Card Summary Header */}
              <div
                onClick={() => toggleExpand(run.id)}
                className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer select-none hover:bg-[#131c2d] transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#172033] border border-cyan-500/30 flex items-center justify-center font-mono font-bold text-xs text-cyan-400 shadow-sm">
                    #{history.length - idx}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white font-mono">{run.id}</span>
                      <span className="text-xs text-slate-400 font-mono">• {run.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Scanned {run.stats.filesScanned} files in {(run.durationMs / 1000).toFixed(2)}s.
                    </p>
                  </div>
                </div>

                {/* Badges & Health */}
                <div className="flex items-center gap-4">
                  {/* Delta Badges */}
                  <div className="flex items-center gap-2 text-xs font-mono">
                    {run.delta.newIssues > 0 && (
                      <span className="px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-300 border border-cyan-800/40">
                        +{run.delta.newIssues} New
                      </span>
                    )}
                    {run.delta.stillUnresolved > 0 && (
                      <span className="px-2 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/40">
                        {run.delta.stillUnresolved} Unresolved
                      </span>
                    )}
                    {run.delta.resolvedIssues > 0 && (
                      <span className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/40">
                        {run.delta.resolvedIssues} Fixed
                      </span>
                    )}
                  </div>

                  {/* Health Score Pill */}
                  <span
                    className={`px-3 py-1 rounded-xl text-xs font-mono font-bold border ${
                      run.healthScore >= 80
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                        : run.healthScore >= 65
                        ? 'bg-amber-950 text-amber-300 border-amber-800'
                        : 'bg-rose-950 text-rose-300 border-rose-800'
                    }`}
                  >
                    {run.healthScore}%
                  </span>

                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Expandable Run Detail */}
              {isExpanded && (
                <div className="px-6 pb-6 pt-2 border-t border-[#1e293b] space-y-4 bg-[#0d131f]/60 font-mono text-xs">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    <div className="p-3 rounded-lg bg-[#090d15] border border-[#1b2538] text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">Missing Keys</span>
                      <span className="text-base font-bold text-rose-400">{run.stats.missingCount}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-[#090d15] border border-[#1b2538] text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">Orphaned Configs</span>
                      <span className="text-base font-bold text-amber-400">{run.stats.orphanedCount}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-[#090d15] border border-[#1b2538] text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">Type Mismatches</span>
                      <span className="text-base font-bold text-purple-400">{run.stats.typeMismatchCount}</span>
                    </div>
                    <div className="p-3 rounded-lg bg-[#090d15] border border-[#1b2538] text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">Exposed Credentials</span>
                      <span className="text-base font-bold text-red-400">{run.stats.secretsDetected}</span>
                    </div>
                  </div>

                  {/* Log Snippets for this run */}
                  <div className="space-y-1.5 pt-2">
                    <span className="text-slate-400 text-[11px] font-semibold flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                      Recorded Audit Logs for this Run:
                    </span>
                    <div className="p-3 rounded-xl bg-[#080b12] border border-[#1b2538] space-y-1 text-[11px] max-h-40 overflow-y-auto">
                      {run.logs.map((log, lIdx) => (
                        <div key={lIdx} className="flex items-center gap-2">
                          <span className="text-slate-500">[{log.timestamp}]</span>
                          <span
                            className={`font-bold uppercase text-[9px] ${
                              log.level === 'error'
                                ? 'text-rose-400'
                                : log.level === 'warn'
                                ? 'text-amber-400'
                                : log.level === 'success'
                                ? 'text-emerald-400'
                                : 'text-cyan-400'
                            }`}
                          >
                            {log.level}
                          </span>
                          <span className="text-slate-300">{log.message}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
