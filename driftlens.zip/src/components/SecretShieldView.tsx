import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Eye,
  EyeOff,
  Copy,
  Check,
  AlertTriangle,
  FileCode,
  Lock,
  Key,
  Database,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { SecretItem, Severity } from '../types';

interface SecretShieldViewProps {
  secrets: SecretItem[];
  onRemediateSecret: (secretId: string) => void;
}

export const SecretShieldView: React.FC<SecretShieldViewProps> = ({
  secrets,
  onRemediateSecret,
}) => {
  const [selectedSecretId, setSelectedSecretId] = useState<string>(secrets[0]?.id || '');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const exposedCount = secrets.filter((s) => s.status === 'exposed').length;
  const activeSecret = secrets.find((s) => s.id === selectedSecretId) || secrets[0];

  const copyMaskedValue = (maskedText: string, id: string) => {
    navigator.clipboard.writeText(maskedText);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-red-500/10 text-red-400 border border-red-500/30">
              SECRET SHIELD • STRICT PRIVACY
            </span>
            <span className="text-xs text-slate-400">• Zero Raw Secret Exposure Guaranteed</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 mt-1">
            <ShieldAlert className="w-6 h-6 text-red-400" />
            Secret Shield — Exposed Credential Scanner
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Detects exposed secrets, API keys, tokens, and database credentials without ever storing or displaying raw secret values.
          </p>
        </div>

        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs font-mono font-bold">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span>{exposedCount} Credentials Exposed</span>
        </div>
      </div>

      {/* Safety Notice Banner */}
      <div className="p-4 rounded-xl bg-[#0e1422] border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-md">
        <div className="flex items-center gap-2.5 text-slate-300">
          <Lock className="w-4 h-4 text-cyan-400 flex-shrink-0" />
          <span>
            <strong>Zero-Knowledge Safeguard:</strong> Raw secret values, passwords, and tokens are NEVER rendered, transmitted, or logged. All values are permanently masked as safe entropy signatures.
          </span>
        </div>
        <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/50 px-2.5 py-1 rounded border border-cyan-800/40 flex-shrink-0">
          Strictly Masked
        </span>
      </div>

      {/* Main Grid: Secrets List (Left) & Deep Remediation Guide (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Secrets List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="p-4 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-3">
            <span className="text-xs font-semibold text-slate-300 block">
              Detected Potential Secrets:
            </span>

            <div className="space-y-2.5 max-h-[580px] overflow-y-auto pr-1">
              {secrets.map((sec) => {
                const isSelected = activeSecret?.id === sec.id;
                const isSecured = sec.status === 'secured';

                return (
                  <div
                    key={sec.id}
                    onClick={() => setSelectedSecretId(sec.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer select-none ${
                      isSelected
                        ? 'bg-[#141d2e] border-red-400/80 shadow-md ring-1 ring-red-400/40'
                        : isSecured
                        ? 'bg-[#0d131f]/40 border-emerald-900/30 opacity-60'
                        : 'bg-[#0e1422] border-[#1e293b] hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <Key className="w-3.5 h-3.5 text-red-400" />
                          <span className="text-xs font-bold text-white truncate">{sec.name}</span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 block truncate">
                          Source: {sec.filePath}:{sec.line}
                        </span>
                      </div>

                      <span
                        className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded border ${
                          sec.severity === 'critical'
                            ? 'bg-red-950 text-red-300 border-red-800'
                            : 'bg-amber-950 text-amber-300 border-amber-800'
                        }`}
                      >
                        {sec.severity} Risk
                      </span>
                    </div>

                    {/* Masked Value Snippet - STRICTLY MASKED */}
                    <div className="p-2 rounded bg-[#090d15] border border-[#1b2538] font-mono text-[11px] text-cyan-300/90 flex items-center justify-between">
                      <span className="truncate pr-2 font-bold tracking-wider">{sec.detectedValueMasked}</span>
                      <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                        <Lock className="w-3 h-3 text-slate-500" /> Masked
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[10px] font-mono text-slate-500">
                      <span>Entropy Score: {sec.entropyScore} / 5.0</span>
                      {isSecured ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> Secured
                        </span>
                      ) : (
                        <span className="text-red-400 font-bold">Exposed in Repo</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (7 Cols): Secret Inspector & Remediation */}
        <div className="lg:col-span-7 space-y-4">
          {activeSecret ? (
            <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] shadow-xl space-y-6">
              {/* Top Banner */}
              <div className="flex items-start justify-between border-b border-[#1e293b] pb-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase text-red-400 font-bold tracking-wider">
                    {activeSecret.ruleId}
                  </span>
                  <h3 className="text-base font-bold text-white">{activeSecret.name}</h3>
                  <div className="text-xs text-slate-400 font-mono">
                    Source Environment / File: <span className="text-cyan-300">{activeSecret.filePath}</span> at line{' '}
                    <span className="text-cyan-300">{activeSecret.line}</span>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1">
                  <span
                    className={`text-xs font-mono font-bold px-2.5 py-1 rounded border ${
                      activeSecret.status === 'secured'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                        : 'bg-red-950 text-red-300 border-red-800 animate-pulse'
                    }`}
                  >
                    {activeSecret.status === 'secured' ? 'KEY SECURED' : 'EXPOSED IN REPO'}
                  </span>
                  <span className="text-[10px] font-mono text-rose-400">
                    Exposure Risk: {activeSecret.severity.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Masked Value Inspection Card */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                  <span>Masked Credential Representation:</span>
                  <span>Pattern: {activeSecret.patternType}</span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#090d16] border border-[#1e293b] flex items-center justify-between font-mono text-xs text-slate-200">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-emerald-400" />
                    <span className="text-cyan-300 font-bold tracking-wider select-all">
                      {activeSecret.detectedValueMasked}
                    </span>
                  </div>

                  <button
                    onClick={() => copyMaskedValue(activeSecret.detectedValueMasked, activeSecret.id)}
                    className="px-2.5 py-1 rounded bg-[#151e2e] hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors flex items-center gap-1"
                  >
                    {copiedId === activeSecret.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied Mask
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" /> Copy Mask
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Recommendation Box */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-[#12192a] to-[#0d131f] border border-[#1e293b] space-y-3 text-xs">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  Recommendation (Move to Secret Manager / .env gitignore):
                </span>
                <p className="text-slate-300 leading-relaxed font-sans">{activeSecret.remediation}</p>

                <div className="p-3.5 rounded-lg bg-[#080d16] border border-[#1c2638] space-y-2 text-[11px] font-mono">
                  <div className="text-slate-400 font-semibold">Immediate Security Steps:</div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-cyan-400 font-bold">1.</span>
                    <span>Rotate or revoke this key in the provider console immediately.</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-cyan-400 font-bold">2.</span>
                    <span>Store value in Google Cloud Secret Manager, AWS Secrets Manager, or Doppler.</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <span className="text-cyan-400 font-bold">3.</span>
                    <span>Add <code className="text-cyan-300 font-bold">.env*</code> to <code className="text-cyan-300 font-bold">.gitignore</code> and remove hardcoded constants.</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-[#1e293b] flex items-center justify-between">
                <span className="text-xs text-slate-500 font-mono">Entropy: {activeSecret.entropyScore} / 5.0</span>

                {activeSecret.status === 'secured' ? (
                  <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-mono font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Secret Rotated & Secured</span>
                  </div>
                ) : (
                  <button
                    onClick={() => onRemediateSecret(activeSecret.id)}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-md transition-all active:scale-95"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Mark Key as Rotated / Secured</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center rounded-2xl bg-[#111827] border border-[#1e293b] text-slate-400 text-xs">
              Select a secret from the list to inspect remediation tips.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
