import React, { useState } from 'react';
import {
  FolderUp,
  Github,
  FileArchive,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Code2,
  Server,
  Layers,
} from 'lucide-react';
import { ProjectConfig } from '../types';

interface UploadViewProps {
  onProjectUploaded: (newProject: ProjectConfig) => void;
  onNavigateToScan: () => void;
}

export const UploadView: React.FC<UploadViewProps> = ({
  onProjectUploaded,
  onNavigateToScan,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  const [uploadedResult, setUploadedResult] = useState<{
    project: ProjectConfig;
    stats: {
      totalFiles: number;
      languages: { name: string; percentage: number; color: string }[];
      configFilesFound: string[];
    };
  } | null>(null);

  const simulateUploadProcess = async (projectName: string, repoUrl?: string) => {
    setUploading(true);
    setProgress(15);
    setCurrentStep('Reading directory contents & unpacking project files...');

    await new Promise((r) => setTimeout(r, 600));
    setProgress(45);
    setCurrentStep('Extracting environment configs (.env.development, .env.staging, .env.production)...');

    await new Promise((r) => setTimeout(r, 700));
    setProgress(80);
    setCurrentStep('Parsing package.json & tsconfig.json dependency trees...');

    await new Promise((r) => setTimeout(r, 600));
    setProgress(100);
    setCurrentStep('Codebase ready for multi-environment drift analysis!');

    try {
      const res = await fetch('/api/projects/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: projectName,
          repoUrl,
          fileCount: 384,
          sampleType: projectName,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setUploadedResult(data);
        onProjectUploaded(data.project);
      }
    } catch {
      // Fallback local
      const mockProj: ProjectConfig = {
        id: `proj_${Date.now()}`,
        name: projectName,
        repoUrl,
        branch: 'main',
        lastScanTime: 'Ready to scan',
        healthScore: 76,
        filesCount: 384,
        languages: [
          { name: 'TypeScript', percentage: 68, color: '#3178c6' },
          { name: 'React / TSX', percentage: 22, color: '#61dafb' },
          { name: 'Config / Env', percentage: 7, color: '#eab308' },
          { name: 'YAML / Docker', percentage: 3, color: '#10b981' },
        ],
        environments: {
          development: { varsCount: 42, status: 'warnings' },
          staging: { varsCount: 38, status: 'critical' },
          production: { varsCount: 36, status: 'critical' },
        },
        modules: [
          { id: 'mod_1', name: 'Application Core', path: 'src/core', filesCount: 42, healthScore: 80, issuesCount: 2, status: 'warnings' },
          { id: 'mod_2', name: 'Billing & Payments', path: 'src/services/billing', filesCount: 28, healthScore: 50, issuesCount: 4, status: 'critical' },
        ],
      };
      setUploadedResult({
        project: mockProj,
        stats: {
          totalFiles: 384,
          languages: mockProj.languages,
          configFilesFound: ['.env.development', '.env.staging', '.env.production', 'package.json', 'tsconfig.json'],
        },
      });
      onProjectUploaded(mockProj);
    } finally {
      setUploading(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const name = file.name.replace(/\.[^/.]+$/, '');
      simulateUploadProcess(`Project: ${name}`);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const name = file.name.replace(/\.[^/.]+$/, '');
      simulateUploadProcess(`Project: ${name}`);
    }
  };

  const handleGithubConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!githubUrl.trim()) return;
    const repoName = githubUrl.split('/').slice(-2).join('/') || githubUrl;
    simulateUploadProcess(`GitHub: ${repoName}`, githubUrl);
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <FolderUp className="w-6 h-6 text-cyan-400" />
          Upload & Connect Codebase
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Upload your local project archive, select a project folder, or connect via GitHub URL to detect
          configuration drift.
        </p>
      </div>

      {/* Upload Methods Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Method 1: Drag and Drop / Local File Picker */}
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`p-8 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center text-center transition-all ${
            dragActive
              ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-950/50'
              : 'border-[#243046] bg-[#101624] hover:border-slate-600'
          }`}
        >
          <div className="w-14 h-14 rounded-2xl bg-[#172033] border border-cyan-500/30 flex items-center justify-center mb-4 text-cyan-400 shadow-md">
            <FileArchive className="w-7 h-7" />
          </div>

          <h3 className="text-base font-bold text-white mb-1">Drag & drop project folder or .zip</h3>
          <p className="text-xs text-slate-400 max-w-xs mb-5">
            Supports ZIP, TAR.GZ archives or local source trees containing `.env*`, `package.json`, and source code.
          </p>

          <label className="cursor-pointer px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-md transition-all active:scale-95">
            <span>Browse Files / Zip</span>
            <input
              type="file"
              className="hidden"
              accept=".zip,.tar,.gz,.json"
              onChange={handleFileInput}
              disabled={uploading}
            />
          </label>
        </div>

        {/* Method 2: Connect GitHub Repository */}
        <div className="p-8 rounded-2xl border border-[#243046] bg-[#101624] flex flex-col justify-between">
          <div>
            <div className="w-14 h-14 rounded-2xl bg-[#172033] border border-slate-700 flex items-center justify-center mb-4 text-white shadow-md">
              <Github className="w-7 h-7" />
            </div>

            <h3 className="text-base font-bold text-white mb-1">Connect GitHub Repository</h3>
            <p className="text-xs text-slate-400 mb-5">
              Connect a public or private GitHub repository URL. DriftLens will analyze branch configurations and
              staged releases.
            </p>

            <form onSubmit={handleGithubConnect} className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="https://github.com/organization/repo-name"
                  value={githubUrl}
                  onChange={(e) => setGithubUrl(e.target.value)}
                  disabled={uploading}
                  className="w-full bg-[#0c1017] border border-[#2d3a4f] rounded-xl px-3.5 py-2.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
              <button
                type="submit"
                disabled={uploading || !githubUrl.trim()}
                className="w-full py-2.5 rounded-xl text-xs font-semibold text-white bg-[#1e293b] hover:bg-slate-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
              >
                <Github className="w-4 h-4" />
                <span>Fetch & Analyze Repo</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Preset Realistic Codebases for Instant Testing */}
      <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Try Pre-Configured Complex Codebases
          </h3>
          <p className="text-xs text-slate-400">
            Instantly load real-world projects exhibiting realistic environment drift without uploading your own zip.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => simulateUploadProcess('Nexus Cloud Platform')}
            disabled={uploading}
            className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] hover:border-cyan-500/50 hover:bg-[#131b2c] transition-all text-left group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-xs text-white group-hover:text-cyan-300 transition-colors">
                Nexus Cloud Platform
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                High Drift
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Full-stack TypeScript + Express + React. Unresolved Stripe key in prod, orphaned Redis password.
            </p>
            <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
              <span>384 files</span> • <span>3 env files</span>
            </div>
          </button>

          <button
            onClick={() => simulateUploadProcess('Fintech Payment Gateway')}
            disabled={uploading}
            className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] hover:border-cyan-500/50 hover:bg-[#131b2c] transition-all text-left group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-xs text-white group-hover:text-cyan-300 transition-colors">
                Fintech Payment Gateway
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Medium Drift
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              KMS Vault & processing microservices. Schema drift between processor and webhook receivers.
            </p>
            <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
              <span>215 files</span> • <span>2 env files</span>
            </div>
          </button>

          <button
            onClick={() => simulateUploadProcess('Omni Commerce Storefront')}
            disabled={uploading}
            className="p-4 rounded-xl bg-[#0e1422] border border-[#1e293b] hover:border-cyan-500/50 hover:bg-[#131b2c] transition-all text-left group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-xs text-white group-hover:text-cyan-300 transition-colors">
                Omni Commerce Storefront
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Multi-tenant
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Next.js commerce platform with missing asset env keys and type mismatches on timeout configs.
            </p>
            <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2">
              <span>512 files</span> • <span>3 env files</span>
            </div>
          </button>
        </div>
      </div>

      {/* Upload Progress Indicator */}
      {uploading && (
        <div className="p-6 rounded-2xl bg-[#111827] border border-cyan-500/40 shadow-xl space-y-4 animate-pulse">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-cyan-300 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
              Processing Codebase Architecture...
            </span>
            <span className="font-mono text-xs text-cyan-400 font-bold">{progress}%</span>
          </div>

          <div className="w-full bg-[#1b2434] rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>

          <p className="text-xs text-slate-400 font-mono">{currentStep}</p>
        </div>
      )}

      {/* Upload Complete Summary View */}
      {uploadedResult && !uploading && (
        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#101827] to-[#0c121e] border border-emerald-500/40 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">{uploadedResult.project.name} Uploaded</h3>
                <p className="text-xs text-slate-400">
                  Codebase ingested and indexed. Ready for cross-environment parity scanning.
                </p>
              </div>
            </div>

            <button
              id="upload-start-scan-cta"
              onClick={onNavigateToScan}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-sm font-extrabold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-lg shadow-cyan-950/40 transition-all active:scale-95 border border-cyan-400/30"
            >
              <span>Start Scan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Project Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-xl bg-[#0a0f19] border border-[#1e293b]">
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">Project Name</span>
              <span className="text-sm font-bold text-white truncate block">{uploadedResult.project.name}</span>
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">Number of Files</span>
              <span className="text-sm font-bold font-mono text-cyan-400">{uploadedResult.stats.totalFiles} files</span>
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">Repository / Target</span>
              <span className="text-sm font-mono text-slate-300 truncate block">{uploadedResult.project.repoUrl || 'Local Upload'}</span>
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400 block">Secret Shield Status</span>
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Protected (Zero Raw Secrets)
              </span>
            </div>
          </div>

          {/* Detected Environments: Development, Staging, Production */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-300 block">
              Detected Environments:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl bg-[#0e1422] border border-[#1e293b] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Development</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                    Detected
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {uploadedResult.project.environments.development.varsCount} configuration keys mapped
                </p>
                <div className="text-[10px] text-slate-500 font-mono">Source: .env.development</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0e1422] border border-[#1e293b] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Staging</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
                    Detected
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {uploadedResult.project.environments.staging.varsCount} configuration keys mapped
                </p>
                <div className="text-[10px] text-slate-500 font-mono">Source: .env.staging</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#0e1422] border border-[#1e293b] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Production</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-500/15 text-rose-400 border border-rose-500/30">
                    Detected
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {uploadedResult.project.environments.production.varsCount} configuration keys mapped
                </p>
                <div className="text-[10px] text-slate-500 font-mono">Source: .env.production</div>
              </div>
            </div>
          </div>

          {/* Languages & File Type Breakdown */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-medium text-slate-300">Detected Languages:</span>
              <span className="font-mono">{uploadedResult.stats.totalFiles} source files</span>
            </div>

            {/* Language distribution bar */}
            <div className="h-3 w-full bg-[#1e293b] rounded-full overflow-hidden flex">
              {uploadedResult.stats.languages.map((lang, idx) => (
                <div
                  key={idx}
                  style={{ width: `${lang.percentage}%`, backgroundColor: lang.color }}
                  title={`${lang.name}: ${lang.percentage}%`}
                  className="h-full first:rounded-l-full last:rounded-r-full"
                />
              ))}
            </div>

            <div className="flex flex-wrap gap-4 pt-1">
              {uploadedResult.stats.languages.map((lang, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: lang.color }} />
                  <span className="text-slate-300 font-medium">{lang.name}</span>
                  <span className="text-slate-500 font-mono text-[11px]">{lang.percentage}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Environment Config Files Detected */}
          <div className="p-4 rounded-xl bg-[#090d15] border border-[#1e293b] space-y-2">
            <span className="text-xs font-semibold text-slate-300 block">
              Detected Configuration Sources:
            </span>
            <div className="flex flex-wrap gap-2">
              {uploadedResult.stats.configFilesFound.map((cfg, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-md bg-[#131b2b] border border-[#233149] text-xs font-mono text-cyan-300 flex items-center gap-1.5"
                >
                  <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                  {cfg}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
