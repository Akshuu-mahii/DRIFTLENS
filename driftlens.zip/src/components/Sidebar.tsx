import React from 'react';
import {
  LayoutDashboard,
  FolderUp,
  Scan,
  Network,
  AlertTriangle,
  GitFork,
  Sparkles,
  ShieldAlert,
  History,
  Terminal,
  Layers,
  ChevronDown,
  FileText,
} from 'lucide-react';
import { ProjectConfig, DriftIssue } from '../types';

export type NavRoute =
  | 'home'
  | 'upload'
  | 'scan'
  | 'health-map'
  | 'issues'
  | 'mind-map'
  | 'fixes'
  | 'secrets'
  | 'history'
  | 'report';

interface SidebarProps {
  currentRoute: NavRoute;
  onNavigate: (route: NavRoute) => void;
  projects: ProjectConfig[];
  activeProject: ProjectConfig | null;
  onSelectProject: (id: string) => void;
  issues: DriftIssue[];
  exposedSecretsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRoute,
  onNavigate,
  projects,
  activeProject,
  onSelectProject,
  issues,
  exposedSecretsCount,
}) => {
  const unresolvedIssues = issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored');
  const missingCount = unresolvedIssues.filter((i) => i.type === 'missing').length;
  const orphanedCount = unresolvedIssues.filter((i) => i.type === 'orphaned').length;
  const typeMismatchCount = unresolvedIssues.filter((i) => i.type === 'type_mismatch').length;

  const navItems: {
    id: NavRoute;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: string | number;
    badgeColor?: string;
  }[] = [
    { id: 'home', label: 'Home', icon: LayoutDashboard },
    { id: 'upload', label: 'Upload Project', icon: FolderUp },
    { id: 'scan', label: 'Scan Project', icon: Scan },
    { id: 'health-map', label: 'Health Map', icon: Network },
    {
      id: 'mind-map',
      label: 'Drift Mind Map',
      icon: GitFork,
      badge: 'Visual Hub',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    },
    {
      id: 'issues',
      label: 'Detected Issues',
      icon: AlertTriangle,
      badge: unresolvedIssues.length,
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    },
    {
      id: 'fixes',
      label: 'Recommended Fix',
      icon: Sparkles,
      badge: unresolvedIssues.length,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'secrets',
      label: 'Secret Shield',
      icon: ShieldAlert,
      badge: 'Protected',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    },
    { id: 'history', label: 'Drift History', icon: History },
    {
      id: 'report',
      label: 'Reports',
      icon: FileText,
      badge: 'Safe Audit',
      badgeColor: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
    },
  ];

  return (
    <aside className="w-64 flex-shrink-0 bg-[#0c1017] border-r border-[#1e293b]/70 flex flex-col h-screen sticky top-0 select-none z-30">
      {/* Brand Header */}
      <div className="p-4 border-b border-[#1e293b]/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/20 via-indigo-500/20 to-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shadow-lg shadow-cyan-950/40">
            <Scan className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div className="absolute inset-0 rounded-xl bg-cyan-400/10 blur-sm -z-10" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base text-white tracking-tight">DriftLens</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                v2.4
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-[130px]">Env Drift Analyzer</p>
          </div>
        </div>
      </div>

      {/* Project Switcher */}
      <div className="p-3 border-b border-[#1e293b]/50">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 mb-1.5">
          Active Codebase
        </div>
        <div className="relative">
          <select
            id="active-project-selector"
            aria-label="Active Codebase"
            value={activeProject?.id || ''}
            onChange={(e) => onSelectProject(e.target.value)}
            className="w-full appearance-none bg-[#111827] border border-[#2d3748] rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 pr-8 cursor-pointer font-medium hover:border-slate-600 transition-colors"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.healthScore}%)
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 py-1">
          Navigation
        </div>
        {navItems.map((item) => {
          const isActive = currentRoute === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              id={`nav-btn-${item.id}`}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 to-indigo-500/10 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-950/20'
                  : 'text-slate-300 hover:text-white hover:bg-[#141b27] border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-300'
                  }`}
                />
                <span className="tracking-tight">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono border ${
                    item.badgeColor || 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Quick Drift Summary Footer */}
      <div className="p-3 bg-[#0a0d14] border-t border-[#1e293b]/70">
        <div className="rounded-lg p-2.5 bg-[#101726] border border-[#1e293b] text-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              Active Drift Breakdown
            </span>
            <span className="text-[10px] font-mono text-slate-400">{unresolvedIssues.length} total</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-center text-[10px] font-mono">
            <div className="bg-rose-950/30 border border-rose-900/40 rounded py-1 px-0.5">
              <span className="block text-rose-400 font-bold">{missingCount}</span>
              <span className="text-slate-400 text-[9px]">Missing</span>
            </div>
            <div className="bg-amber-950/30 border border-amber-900/40 rounded py-1 px-0.5">
              <span className="block text-amber-400 font-bold">{orphanedCount}</span>
              <span className="text-slate-400 text-[9px]">Orphaned</span>
            </div>
            <div className="bg-purple-950/30 border border-purple-900/40 rounded py-1 px-0.5">
              <span className="block text-purple-400 font-bold">{typeMismatchCount}</span>
              <span className="text-slate-400 text-[9px]">Mismatch</span>
            </div>
          </div>
        </div>

        <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 px-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-slate-300">Engine Online</span>
          </span>
          <span className="font-mono text-[10px] text-slate-400">Port 3000</span>
        </div>
      </div>

      {/* User / Profile Section */}
      <div className="p-3 bg-[#080b11] border-t border-[#1e293b]/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-blue-700 text-white font-bold text-xs flex items-center justify-center shadow-sm">
              AM
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#080b11]" />
          </div>
          <div className="text-left">
            <p className="text-xs font-semibold text-slate-200 leading-tight">Alex Morgan</p>
            <p className="text-[10px] text-slate-400 leading-tight">DevOps Engineer</p>
          </div>
        </div>
        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
          PRO
        </span>
      </div>
    </aside>
  );
};
