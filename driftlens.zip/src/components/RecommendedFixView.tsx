import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  EyeOff,
  Code2,
  FileCode,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Zap,
  HelpCircle,
  Layers,
  Check,
  Copy,
} from 'lucide-react';
import { DriftIssue, DriftType, Severity } from '../types';

interface RecommendedFixViewProps {
  issues: DriftIssue[];
  selectedIssueId?: string;
  onApplyFix: (issueId: string) => void;
  onIgnoreIssue: (issueId: string) => void;
}

export const RecommendedFixView: React.FC<RecommendedFixViewProps> = ({
  issues,
  selectedIssueId,
  onApplyFix,
  onIgnoreIssue,
}) => {
  const [activeIssueId, setActiveIssueId] = useState<string>(
    selectedIssueId || issues[0]?.id || ''
  );
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [aiStatusMessage, setAiStatusMessage] = useState<string | null>(null);
  const [groupBy, setGroupBy] = useState<'type' | 'priority'>('type');
  const [copied, setCopied] = useState(false);

  const activeIssue = issues.find((i) => i.id === activeIssueId) || issues[0];
  const unresolvedIssues = issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored');

  const handleCopyFix = () => {
    if (!activeIssue) return;
    const textToCopy =
      activeIssue.fixSuggestion.diffAfter ||
      activeIssue.fixSuggestion.safeActionSummary ||
      activeIssue.fixSuggestion.explanation;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleGenerateAiFix = async (issue: DriftIssue) => {
    setIsGeneratingAi(true);
    setAiStatusMessage(null);
    try {
      // Send ONLY safe metadata to backend — no secret values!
      const res = await fetch('/api/ai/fix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issueId: issue.id,
          safeMetadata: {
            keyOrTarget: issue.keyOrTarget,
            type: issue.type,
            category: issue.category,
            filePath: issue.filePath,
            line: issue.line,
          },
        }),
      });
      const data = await res.json();
      if (data.success && data.fixSuggestion) {
        issue.fixSuggestion = data.fixSuggestion;
        setAiStatusMessage(
          data.source === 'gemini'
            ? '✨ Synthesized via Gemini 3.8 Flash using safe configuration metadata.'
            : '✨ Generated via deterministic drift rule heuristics.'
        );
      }
    } catch {
      setAiStatusMessage('Generated via local heuristic rule pattern.');
    } finally {
      setIsGeneratingAi(false);
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/30">
              SAFE AI REMEDIATION
            </span>
            <span className="text-xs text-slate-400">• Zero Secret Exposure</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5 mt-1">
            <Sparkles className="w-6 h-6 text-indigo-400" />
            Recommended Fixes & Code Diffs
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            AI-synthesized diffs to eliminate environment drift across Development, Staging, and Production.
          </p>
        </div>

        {/* Group By Filter */}
        <div className="flex items-center gap-2 bg-[#111827] p-1 rounded-xl border border-[#1e293b]">
          <span className="text-[11px] font-semibold text-slate-400 px-2">Group by:</span>
          <button
            onClick={() => setGroupBy('type')}
            className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-colors ${
              groupBy === 'type'
                ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Issue Type
          </button>
          <button
            onClick={() => setGroupBy('priority')}
            className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-colors ${
              groupBy === 'priority'
                ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Priority
          </button>
        </div>
      </div>

      {/* Safe Metadata Guarantee Card */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-[#0c1424] via-[#0e172a] to-[#0c1424] border border-cyan-500/30 flex items-center gap-3 text-xs shadow-md">
        <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 flex-shrink-0">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div className="space-y-0.5">
          <span className="font-bold text-cyan-300">Privacy & Secret Shield Guarantee:</span>
          <p className="text-slate-300">
            Fix recommendations are generated strictly from <strong>safe structural metadata</strong> (key names, presence/absence flags, AST call sites, and schema types). 
            Actual secret credentials or production passwords are NEVER sent to the AI service.
          </p>
        </div>
      </div>

      {/* Main Grid: Left issue selector list & Right Diff Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (4 Cols): Issues List */}
        <div className="lg:col-span-4 space-y-3">
          <div className="p-4 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">Drift Candidates:</span>
              <span className="text-xs font-mono text-indigo-400">{unresolvedIssues.length} pending</span>
            </div>

            <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
              {issues.map((issue) => {
                const isSelected = activeIssue?.id === issue.id;
                const isResolved = issue.status === 'resolved';

                return (
                  <div
                    key={issue.id}
                    onClick={() => {
                      setActiveIssueId(issue.id);
                      setAiStatusMessage(null);
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      isSelected
                        ? 'bg-[#141b2c] border-indigo-400 shadow-md ring-1 ring-indigo-400/40'
                        : isResolved
                        ? 'bg-[#0d131f]/40 border-emerald-900/30 opacity-60'
                        : 'bg-[#0e1422] border-[#1e293b] hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">
                        {issue.type.replace('_', ' ')}
                      </span>
                      <span
                        className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded ${
                          issue.severity === 'critical'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}
                      >
                        {issue.severity}
                      </span>
                    </div>

                    <div className="text-xs font-bold text-white truncate mb-1">{issue.keyOrTarget}</div>
                    <div className="text-[11px] text-slate-400 truncate">{issue.filePath}</div>

                    {isResolved && (
                      <div className="mt-2 text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Fix Applied (Resolved)
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (8 Cols): Diff Viewer & Action Controls */}
        <div className="lg:col-span-8 space-y-4">
          {activeIssue ? (
            <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] shadow-xl space-y-6">
              {/* Fix Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-[#1e293b] pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                      {activeIssue.keyOrTarget}
                    </span>
                    <span className="text-xs font-mono text-slate-400">Target File: {activeIssue.fixSuggestion.targetFile}</span>
                  </div>
                  <h3 className="text-base font-bold text-white">{activeIssue.title}</h3>
                </div>

                <button
                  onClick={() => handleGenerateAiFix(activeIssue)}
                  disabled={isGeneratingAi}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-md transition-all active:scale-95 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                  <span>{isGeneratingAi ? 'Synthesizing with Gemini...' : 'Regenerate with AI'}</span>
                </button>
              </div>

              {aiStatusMessage && (
                <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/30 text-xs text-indigo-200 flex items-center gap-2 animate-in fade-in">
                  <Sparkles className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>{aiStatusMessage}</span>
                </div>
              )}

              {/* Rationale / Explanation */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-300 block">Remediation Rationale:</span>
                <p className="text-xs text-slate-300 bg-[#0c121e] p-3.5 rounded-xl border border-[#1e293b] leading-relaxed">
                  {activeIssue.fixSuggestion.explanation}
                </p>
              </div>

              {/* Code Diff Box */}
              <div className="space-y-2 font-mono text-xs">
                <div className="flex items-center justify-between text-xs text-slate-400 font-sans">
                  <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <Code2 className="w-4 h-4 text-cyan-400" />
                    Proposed Code / Config Diff:
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">{activeIssue.fixSuggestion.targetFile}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* Before (Diff Red) */}
                  <div className="rounded-xl bg-[#0a0709] border border-rose-900/40 overflow-hidden">
                    <div className="px-3 py-1.5 bg-rose-950/40 border-b border-rose-900/40 text-rose-300 text-[11px] font-bold flex items-center justify-between">
                      <span>BEFORE (Drifted / Absent)</span>
                      <span className="text-[10px] text-rose-400 font-mono">- Removal</span>
                    </div>
                    <pre className="p-3 text-[11px] text-rose-200/90 overflow-x-auto leading-relaxed whitespace-pre-wrap">
                      {activeIssue.fixSuggestion.diffBefore}
                    </pre>
                  </div>

                  {/* After (Diff Green) */}
                  <div className="rounded-xl bg-[#060c09] border border-emerald-900/40 overflow-hidden">
                    <div className="px-3 py-1.5 bg-emerald-950/40 border-b border-emerald-900/40 text-emerald-300 text-[11px] font-bold flex items-center justify-between">
                      <span>AFTER (Synchronized)</span>
                      <span className="text-[10px] text-emerald-400 font-mono">+ Insertion</span>
                    </div>
                    <pre className="p-3 text-[11px] text-emerald-200/90 overflow-x-auto leading-relaxed whitespace-pre-wrap">
                      {activeIssue.fixSuggestion.diffAfter}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Safe Action Summary Directive */}
              <div className="p-3.5 rounded-xl bg-[#0c121e] border border-[#1e293b] flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono">Action: {activeIssue.fixSuggestion.safeActionSummary}</span>
                <span className="text-[10px] text-cyan-400 font-mono">Safe Patch Ready</span>
              </div>

              {/* Action Buttons: Copy Fix, Mark as Resolved, Apply Fix */}
              <div className="pt-4 border-t border-[#1e293b] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    id="copy-fix-btn"
                    onClick={handleCopyFix}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-200 bg-[#1e293b] hover:bg-slate-700 transition-all border border-slate-700 shadow-sm"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Copy Fix</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onIgnoreIssue(activeIssue.id)}
                    className="px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 bg-[#161f2e] hover:bg-slate-700 transition-colors"
                  >
                    Ignore Finding
                  </button>
                </div>

                <div className="flex items-center gap-2.5">
                  {activeIssue.status !== 'resolved' && (
                    <button
                      id="mark-as-resolved-btn"
                      onClick={() => onApplyFix(activeIssue.id)}
                      className="px-4 py-2.5 rounded-xl text-xs font-semibold text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 transition-colors flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark as Resolved</span>
                    </button>
                  )}

                  {activeIssue.status === 'resolved' ? (
                    <div className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-bold font-mono">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Patch Applied & Verified</span>
                    </div>
                  ) : (
                    <button
                      id="apply-fix-primary-btn"
                      onClick={() => onApplyFix(activeIssue.id)}
                      className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-lg shadow-emerald-950/40 transition-all active:scale-95"
                    >
                      <Check className="w-4 h-4" />
                      <span>Apply Fix</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center rounded-2xl bg-[#111827] border border-[#1e293b] text-slate-400 text-xs">
              No drift issue selected. Choose one from the list on the left.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
