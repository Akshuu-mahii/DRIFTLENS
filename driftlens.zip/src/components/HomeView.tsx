import React from 'react';
import {
  Activity,
  AlertTriangle,
  ShieldAlert,
  FileCode,
  Layers,
  ArrowUpRight,
  GitFork,
  Sparkles,
  Network,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Zap,
  FileText,
} from 'lucide-react';
import { ProjectConfig, DriftIssue, SecretItem, ScanRun } from '../types';
import { NavRoute } from './Sidebar';

interface HomeViewProps {
  project: ProjectConfig | null;
  issues: DriftIssue[];
  secrets: SecretItem[];
  history: ScanRun[];
  onNavigate: (route: NavRoute) => void;
  onTriggerScan: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  project,
  issues,
  secrets,
  history,
  onNavigate,
  onTriggerScan,
}) => {
  const unresolvedIssues = issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored');
  const missingCount = unresolvedIssues.filter((i) => i.type === 'missing').length;
  const orphanedCount = unresolvedIssues.filter((i) => i.type === 'orphaned').length;
  const typeMismatchCount = unresolvedIssues.filter((i) => i.type === 'type_mismatch').length;
  const criticalCount = unresolvedIssues.filter((i) => i.severity === 'critical').length;
  const exposedSecretsCount = secrets.filter((s) => s.status === 'exposed').length;

  const healthScore = project?.healthScore ?? 74;
  const healthLabel =
    healthScore >= 90
      ? 'Exceptional Parity'
      : healthScore >= 75
      ? 'Good with Minor Drift'
      : healthScore >= 60
      ? 'Moderate Configuration Drift'
      : 'Critical Drift Detected';

  const healthGrade =
    healthScore >= 90 ? 'A' : healthScore >= 80 ? 'B+' : healthScore >= 70 ? 'B' : healthScore >= 60 ? 'C' : 'D';

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Top Banner / Hero */}
      <div className="p-8 rounded-2xl bg-gradient-to-br from-[#101726] via-[#0d131f] to-[#0a0f18] border border-[#1e293b] shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                DRIFTLENS
              </span>
              <span className="text-xs text-slate-400">• v2.4 Active Engine</span>
            </div>
            <h1 className="text-3xl font-black text-white tracking-tight">
              Project Health & Configuration Drift Detection
            </h1>
            <p className="text-base text-slate-300 max-w-2xl font-normal leading-relaxed">
              Detect configuration problems before they become deployment failures.
            </p>
          </div>

          {/* Large Primary Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              id="home-upload-primary-btn"
              onClick={() => onNavigate('upload')}
              className="flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl text-sm font-extrabold text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:via-indigo-500 hover:to-cyan-500 shadow-xl shadow-cyan-950/50 transition-all active:scale-95 border border-cyan-400/30"
            >
              <Zap className="w-4 h-4 text-cyan-200" />
              <span>Upload Project</span>
            </button>
            <button
              id="home-start-scan-btn"
              onClick={onTriggerScan}
              className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl text-xs font-bold text-slate-200 bg-[#162033] hover:bg-[#1e2c45] border border-[#2d3f63] transition-all"
            >
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Scan Active Project</span>
            </button>
          </div>
        </div>

        {/* Three Small Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-[#1e293b]/70">
          <div
            onClick={() => onNavigate('issues')}
            className="p-4 rounded-xl bg-[#0c121e] border border-[#1e293b] hover:border-cyan-500/40 cursor-pointer transition-all space-y-1.5 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="text-base">🔍</span> Detect Configuration Drift
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
            </div>
            <p className="text-[12px] text-slate-400 leading-relaxed">
              Identify missing keys, unreferenced orphaned variables, and cross-environment type mismatches.
            </p>
          </div>

          <div
            onClick={() => onNavigate('secrets')}
            className="p-4 rounded-xl bg-[#0c121e] border border-[#1e293b] hover:border-emerald-500/40 cursor-pointer transition-all space-y-1.5 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="text-base">🔐</span> Protect Secrets
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
            </div>
            <p className="text-[12px] text-slate-400 leading-relaxed">
              Secret Shield guarantees zero exposure of API tokens, database passwords, or credentials.
            </p>
          </div>

          <div
            onClick={() => onNavigate('mind-map')}
            className="p-4 rounded-xl bg-[#0c121e] border border-[#1e293b] hover:border-indigo-500/40 cursor-pointer transition-all space-y-1.5 group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="text-base">🧠</span> Understand Problems Visually
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
            </div>
            <p className="text-[12px] text-slate-400 leading-relaxed">
              Drift Mind Map provides visual topology branching from environments to exact source lines and remediation.
            </p>
          </div>
        </div>
      </div>

      {/* Small Dashboard Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Project Status */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] space-y-2">
          <span className="text-xs font-medium text-slate-400 block">Project Status</span>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-base font-bold text-white truncate">{project?.name || 'My Project'}</span>
          </div>
          <p className="text-[11px] text-slate-400 font-mono">Branch: {project?.branch || 'main'}</p>
        </div>

        {/* Configuration Health */}
        <div className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Configuration Health</span>
            <span className="text-xs font-mono font-bold text-cyan-400">{healthScore}%</span>
          </div>
          <div className="w-full bg-[#1e293b] rounded-full h-2 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                healthScore >= 80 ? 'bg-emerald-400' : healthScore >= 65 ? 'bg-amber-400' : 'bg-rose-500'
              }`}
              style={{ width: `${healthScore}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-400">{healthLabel}</p>
        </div>

        {/* Critical Issues */}
        <div
          onClick={() => onNavigate('issues')}
          className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] hover:border-rose-500/40 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Critical Issues</span>
            <AlertTriangle className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-rose-400">{criticalCount}</span>
            <span className="text-xs text-rose-300">requires review</span>
          </div>
          <p className="text-[11px] text-slate-400">{unresolvedIssues.length} total active issues</p>
        </div>

        {/* Last Scan */}
        <div
          onClick={() => onNavigate('history')}
          className="p-5 rounded-xl bg-[#111827] border border-[#1e293b] hover:border-cyan-500/40 cursor-pointer transition-all space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Last Scan</span>
            <Clock className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
          </div>
          <span className="text-sm font-bold text-white block truncate">{project?.lastScanTime || 'Just now'}</span>
          <p className="text-[11px] text-slate-400 font-mono">Today, 07:00 AM (AST Engine)</p>
        </div>
      </div>

      {/* Cross-Environment Parity Matrix & Drift Type Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Environment Parity Matrix */}
        <div className="lg:col-span-2 p-6 rounded-xl bg-[#111827] border border-[#1e293b] space-y-4">
          <div className="flex items-center justify-between border-b border-[#1e293b]/70 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <Network className="w-4 h-4 text-cyan-400" />
                Cross-Environment Configuration Parity
              </h3>
              <p className="text-xs text-slate-400">
                Comparing configuration declarations and runtime references between environments.
              </p>
            </div>
            <button
              onClick={() => onNavigate('health-map')}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              View Full Map <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-2">
            {/* Development */}
            <div className="p-4 rounded-lg bg-[#0e1422] border border-[#1e293b] space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-xs text-white">Development</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                {project?.environments?.development?.varsCount || 42}
                <span className="text-xs font-normal text-slate-400 ml-1">keys</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Baseline environment. All referenced keys present locally.
              </p>
              <div className="pt-1 text-[10px] text-emerald-400/90 font-mono">Status: 96% Parity</div>
            </div>

            {/* Staging */}
            <div className="p-4 rounded-lg bg-[#0e1422] border border-amber-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-xs text-white">Staging</span>
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              </div>
              <div className="text-2xl font-bold font-mono text-amber-400">
                {project?.environments?.staging?.varsCount || 38}
                <span className="text-xs font-normal text-slate-400 ml-1">keys</span>
              </div>
              <p className="text-[11px] text-slate-400">
                4 keys missing compared to Development. 1 type mismatch.
              </p>
              <div className="pt-1 text-[10px] text-amber-400 font-mono">Status: 82% Parity (Warnings)</div>
            </div>

            {/* Production */}
            <div className="p-4 rounded-lg bg-[#0e1422] border border-rose-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-xs text-white">Production</span>
                <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" />
              </div>
              <div className="text-2xl font-bold font-mono text-rose-400">
                {project?.environments?.production?.varsCount || 36}
                <span className="text-xs font-normal text-slate-400 ml-1">keys</span>
              </div>
              <p className="text-[11px] text-slate-400">
                6 keys missing. Critical drift on NEXT_PUBLIC_STRIPE_KEY.
              </p>
              <div className="pt-1 text-[10px] text-rose-400 font-mono">Status: 68% Parity (Critical)</div>
            </div>
          </div>

          {/* Module Health Quick Bar */}
          <div className="pt-3 border-t border-[#1e293b]/50">
            <span className="text-xs font-semibold text-slate-300 block mb-2">Module Health At A Glance:</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {project?.modules?.map((m) => (
                <div
                  key={m.id}
                  onClick={() => onNavigate('health-map')}
                  className="p-2.5 rounded-lg bg-[#0d131f] border border-[#1b2536] hover:border-slate-600 transition-colors cursor-pointer flex items-center justify-between"
                >
                  <div className="truncate pr-2">
                    <span className="text-xs font-medium text-slate-200 block truncate">{m.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{m.path}</span>
                  </div>
                  <span
                    className={`text-xs font-mono font-bold px-1.5 py-0.5 rounded ${
                      m.healthScore >= 85
                        ? 'text-emerald-400 bg-emerald-950/40'
                        : m.healthScore >= 65
                        ? 'text-amber-400 bg-amber-950/40'
                        : 'text-rose-400 bg-rose-950/40'
                    }`}
                  >
                    {m.healthScore}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Drift Categorization & Quick Actions */}
        <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] space-y-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight mb-1 flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Drift Classification
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Breakdown of detected codebase anomalies by category.
            </p>

            <div className="space-y-3">
              {/* Missing */}
              <div
                onClick={() => onNavigate('issues')}
                className="p-3 rounded-lg bg-[#0e1422] border border-[#1e293b] hover:border-rose-500/30 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                    <XCircle className="w-3.5 h-3.5 text-rose-400" />
                    Missing References
                  </span>
                  <span className="text-xs font-mono font-bold text-rose-400">{missingCount}</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Referenced in code but absent in configs or dependencies.
                </p>
              </div>

              {/* Orphaned */}
              <div
                onClick={() => onNavigate('issues')}
                className="p-3 rounded-lg bg-[#0e1422] border border-[#1e293b] hover:border-amber-500/30 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                    Orphaned Entities
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-400">{orphanedCount}</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Config keys or files defined but never referenced anywhere.
                </p>
              </div>

              {/* Type Mismatch */}
              <div
                onClick={() => onNavigate('issues')}
                className="p-3 rounded-lg bg-[#0e1422] border border-[#1e293b] hover:border-purple-500/30 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-purple-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-purple-400" />
                    Type / Schema Inconsistency
                  </span>
                  <span className="text-xs font-mono font-bold text-purple-400">{typeMismatchCount}</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Format collisions across environments or frontend/backend schemas.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-[#1e293b] space-y-2">
            <button
              onClick={onTriggerScan}
              className="w-full py-2.5 rounded-lg text-xs font-semibold text-white bg-[#1e293b] hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
            >
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Run Parity Scan Now</span>
            </button>
            <button
              onClick={() => onNavigate('report')}
              className="w-full py-2.5 rounded-lg text-xs font-semibold text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 transition-colors flex items-center justify-center gap-2"
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>Generate Safe Drift Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Scans Table */}
      <div className="p-6 rounded-xl bg-[#111827] border border-[#1e293b] space-y-4">
        <div className="flex items-center justify-between border-b border-[#1e293b]/70 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              Recent Codebase Scan Runs
            </h3>
            <p className="text-xs text-slate-400">
              Audit logs and health score progression across commits and CI runs.
            </p>
          </div>
          <button
            onClick={() => onNavigate('history')}
            className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            All History <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1e293b] text-slate-400 font-semibold font-mono text-[11px]">
                <th className="py-2.5 px-3">Scan ID</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Health Score</th>
                <th className="py-2.5 px-3">Issues Found</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Delta Impact</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e293b]/50">
              {history.slice(0, 4).map((scan) => (
                <tr key={scan.id} className="hover:bg-[#141d2d] transition-colors">
                  <td className="py-3 px-3 font-mono text-cyan-400 font-medium">{scan.id}</td>
                  <td className="py-3 px-3 text-slate-300">{scan.timestamp}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded font-mono font-bold text-[11px] ${
                        scan.healthScore >= 80
                          ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                          : scan.healthScore >= 65
                          ? 'bg-amber-950/50 text-amber-300 border border-amber-800/40'
                          : 'bg-rose-950/50 text-rose-300 border border-rose-800/40'
                      }`}
                    >
                      {scan.healthScore}%
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-200">
                    {scan.stats.issuesFound} active ({scan.stats.resolvedCount} resolved)
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-400">
                    {(scan.durationMs / 1000).toFixed(2)}s
                  </td>
                  <td className="py-3 px-3">
                    {scan.delta.scoreChange > 0 ? (
                      <span className="text-emerald-400 font-mono text-xs">
                        +{scan.delta.scoreChange}% health
                      </span>
                    ) : scan.delta.newIssues > 0 ? (
                      <span className="text-rose-400 font-mono text-xs">
                        +{scan.delta.newIssues} new issues
                      </span>
                    ) : (
                      <span className="text-slate-400 font-mono text-xs">Unchanged</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => onNavigate('history')}
                      className="px-2.5 py-1 rounded bg-[#1e293b] hover:bg-slate-700 text-slate-200 text-[11px] font-medium transition-colors"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
