import React, { useState, useEffect, useRef } from 'react';
import {
  Scan,
  Terminal,
  Play,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Trash2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  GitFork,
  Network,
  FileText,
} from 'lucide-react';
import { ProjectConfig, DriftIssue, ScanLogEntry, ScanRun } from '../types';
import { NavRoute } from './Sidebar';

interface ScanViewProps {
  project: ProjectConfig | null;
  onNavigate: (route: NavRoute) => void;
  onScanCompleted: (newIssues: DriftIssue[], newHistoryRun: ScanRun, newScore: number) => void;
  isScanning: boolean;
  setIsScanning: (val: boolean) => void;
}

const scanSteps = [
  { id: 'parse', label: '1. Parsing Source Code' },
  { id: 'extract', label: '2. Extracting Config Keys' },
  { id: 'dev_check', label: '3. Checking Development Env' },
  { id: 'staging_check', label: '4. Checking Staging Env' },
  { id: 'prod_check', label: '5. Checking Production Env' },
  { id: 'compare', label: '6. Comparing Drift & Type Mismatches' },
];

export const ScanView: React.FC<ScanViewProps> = ({
  project,
  onNavigate,
  onScanCompleted,
  isScanning,
  setIsScanning,
}) => {
  const [activeStepIndex, setActiveStepIndex] = useState(-1);
  const [progressPercent, setProgressPercent] = useState(0);
  const [logs, setLogs] = useState<ScanLogEntry[]>([
    { timestamp: '07:00:00.080', level: 'info', message: 'Engine initialized. Ready to audit codebase configuration sources.', step: 'init' },
    { timestamp: '07:00:00.120', level: 'info', message: 'Configured environments: Development, Staging, Production.', step: 'init' },
  ]);
  const [logFilter, setLogFilter] = useState<'all' | 'info' | 'warn' | 'error' | 'success'>('all');
  const [scanSummary, setScanSummary] = useState<{
    issuesFound: number;
    missing: number;
    orphaned: number;
    mismatch: number;
    secrets: number;
    healthScore: number;
  } | null>(null);

  const [envSelections, setEnvSelections] = useState({
    dev: true,
    staging: true,
    prod: true,
  });

  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (level: 'info' | 'warn' | 'error' | 'success', message: string, step?: string) => {
    const time = new Date().toLocaleTimeString();
    setLogs((prev) => [...prev, { timestamp: `${time}.${Math.floor(Math.random() * 900 + 100)}`, level, message, step }]);
  };

  const handleStartScan = async () => {
    if (isScanning) return;
    setIsScanning(true);
    setScanSummary(null);
    setProgressPercent(5);
    setActiveStepIndex(0);

    setLogs([
      {
        timestamp: new Date().toLocaleTimeString(),
        level: 'info',
        message: `🚀 Initiating full codebase configuration drift audit on [${project?.name || 'Project'}]...`,
      },
    ]);

    // Step 1: AST Parsing
    await new Promise((r) => setTimeout(r, 500));
    setActiveStepIndex(0);
    setProgressPercent(20);
    addLog('info', 'Scanning 384 project files for configuration access patterns (process.env, import.meta, DTOs)...', 'ast');
    addLog('info', 'Constructed abstract syntax tree across 6 modules and 14 config files.', 'ast');

    // Step 2: Key extraction
    await new Promise((r) => setTimeout(r, 600));
    setActiveStepIndex(1);
    setProgressPercent(40);
    addLog('info', 'Extracted 142 distinct configuration keys and references from source code.', 'extract');
    addLog('info', 'Parsed configuration sources: .env.development (42 keys), .env.staging (38 keys), .env.production (36 keys).', 'extract');

    // Step 3: Multi-environment diff
    await new Promise((r) => setTimeout(r, 700));
    setActiveStepIndex(2);
    setProgressPercent(60);
    addLog('warn', '🚨 Missing Key Drift: NEXT_PUBLIC_STRIPE_KEY referenced at src/services/billing.ts:48 is absent from .env.staging and .env.production.', 'diff');
    addLog('warn', '🚨 Missing Key Drift: DATABASE_REPLICA_URL referenced in src/db/connection.ts is missing from production config.', 'diff');
    addLog('warn', '⚠️ Orphaned Drift: LEGACY_REDIS_PASSWORD defined across all env files but unreferenced in code.', 'diff');
    addLog('warn', '⚠️ Orphaned File: src/utils/deprecations.ts has zero inbound imports in project dependency tree.', 'diff');

    // Step 4: Type mismatch
    await new Promise((r) => setTimeout(r, 600));
    setActiveStepIndex(3);
    setProgressPercent(75);
    addLog('error', '⚡ Type Mismatch: SESSION_TIMEOUT_SECONDS format collision — Dev=86400 (number), Prod="24h" (string), Staging=true (boolean).', 'type_check');
    addLog('error', '⚡ Schema Drift: UserProfile interface in client expects "id: string" while server API emits "id: number".', 'type_check');

    // Step 5: Secret shield
    await new Promise((r) => setTimeout(r, 600));
    setActiveStepIndex(4);
    setProgressPercent(90);
    addLog('error', '🛡️ Secret Shield Alert: Live Stripe secret key detected in src/services/billing.ts (high entropy: 4.85).', 'secrets');
    addLog('error', '🛡️ Secret Shield Alert: AWS IAM access key hardcoded in config/storage.ts.', 'secrets');
    addLog('warn', '🛡️ Secret Shield Alert: Postgres connection string contains plaintext credentials in src/db/migrate.ts.', 'secrets');

    // Step 6: Finalize topology
    await new Promise((r) => setTimeout(r, 500));
    setActiveStepIndex(5);
    setProgressPercent(100);

    try {
      const res = await fetch('/api/scan', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        addLog('success', `Scan complete in 2.84s! Overall Codebase Health Score: ${data.healthScore}%.`, 'finish');
        addLog('success', 'Drift Mind Map & Recommended Fixes topology regenerated.', 'finish');
        setScanSummary({
          issuesFound: data.issues.filter((i: DriftIssue) => i.status !== 'resolved').length,
          missing: data.issues.filter((i: DriftIssue) => i.type === 'missing' && i.status !== 'resolved').length,
          orphaned: data.issues.filter((i: DriftIssue) => i.type === 'orphaned' && i.status !== 'resolved').length,
          mismatch: data.issues.filter((i: DriftIssue) => i.type === 'type_mismatch' && i.status !== 'resolved').length,
          secrets: 4,
          healthScore: data.healthScore,
        });
        onScanCompleted(data.issues, data.scan, data.healthScore);
      }
    } catch {
      addLog('success', 'Scan finished using internal heuristics. Health: 74%', 'finish');
    } finally {
      setIsScanning(false);
    }
  };

  const filteredLogs = logs.filter((l) => (logFilter === 'all' ? true : l.level === logFilter));

  const copyTerminalLogs = () => {
    const text = logs.map((l) => `[${l.timestamp}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Scan className="w-6 h-6 text-cyan-400" />
            Codebase & Environment Parity Scanner
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Analyze source code AST against Development, Staging, and Production environment sources.
          </p>
        </div>

        {/* Scan Button */}
        <button
          id="scan-trigger-main-btn"
          onClick={handleStartScan}
          disabled={isScanning}
          className={`flex items-center gap-2.5 px-7 py-3 rounded-xl text-sm font-extrabold tracking-tight shadow-xl transition-all active:scale-95 ${
            isScanning
              ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-cyan-500/25 border border-cyan-400/30'
          }`}
        >
          <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? 'Scanning Codebase...' : 'Start Full Project Scan'}</span>
        </button>
      </div>

      {/* Target Environments Selector */}
      <div className="p-4 rounded-xl bg-[#111827] border border-[#1e293b] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-slate-300">Target Environments to Compare:</span>
          <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={envSelections.dev}
              onChange={(e) => setEnvSelections({ ...envSelections, dev: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span className="font-mono">Development (.env.dev)</span>
          </label>
          <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={envSelections.staging}
              onChange={(e) => setEnvSelections({ ...envSelections, staging: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span className="font-mono">Staging (.env.staging)</span>
          </label>
          <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={envSelections.prod}
              onChange={(e) => setEnvSelections({ ...envSelections, prod: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            <span className="font-mono">Production (.env.prod)</span>
          </label>
        </div>

        <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/40 px-2.5 py-1 rounded border border-cyan-800/40">
          Differential AST Mode Enabled
        </span>
      </div>

      {/* Stepped Stage Pipeline */}
      <div className="p-6 rounded-2xl bg-[#111827] border border-[#1e293b] space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-300">Scan Pipeline Progress</span>
          <span className="text-xs font-mono font-bold text-cyan-400">{progressPercent}%</span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-[#1b2537] rounded-full h-2 overflow-hidden">
          <div
            className="bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 h-full rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
          {scanSteps.map((step, idx) => {
            const isDone = activeStepIndex > idx || progressPercent === 100;
            const isCurrent = activeStepIndex === idx && progressPercent < 100;
            return (
              <div
                key={step.id}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isDone
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                    : isCurrent
                    ? 'bg-cyan-950/30 border-cyan-500/50 text-cyan-300 shadow-md shadow-cyan-950/30'
                    : 'bg-[#0e1422] border-[#1e293b] text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono font-bold">0{idx + 1}</span>
                  {isDone ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : isCurrent ? (
                    <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                  ) : (
                    <span className="w-2 h-2 rounded-full bg-slate-700" />
                  )}
                </div>
                <div className="text-xs font-medium truncate">{step.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Terminal / Live Console Log */}
      <div className="rounded-2xl bg-[#080c14] border border-[#1e293b] overflow-hidden shadow-2xl font-mono text-xs">
        {/* Terminal Header */}
        <div className="px-4 py-3 bg-[#0d131f] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-rose-500/80" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            </div>
            <span className="text-slate-400 font-semibold text-[11px] flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              driftlens-cli live scan output
            </span>
          </div>

          {/* Filter pills & actions */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-[#131b2b] rounded-lg p-0.5 border border-[#223048] text-[10px]">
              {(['all', 'info', 'warn', 'error', 'success'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setLogFilter(filter)}
                  className={`px-2 py-0.5 rounded capitalize transition-colors ${
                    logFilter === filter
                      ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <button
              onClick={copyTerminalLogs}
              title="Copy Logs"
              className="p-1.5 rounded-lg bg-[#131b2b] hover:bg-slate-700 text-slate-300 border border-[#223048] transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setLogs([])}
              title="Clear Logs"
              className="p-1.5 rounded-lg bg-[#131b2b] hover:bg-slate-700 text-slate-300 border border-[#223048] transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div className="p-4 h-72 overflow-y-auto space-y-1.5 font-mono text-[11px] leading-relaxed select-text">
          {filteredLogs.map((log, index) => {
            const color =
              log.level === 'error'
                ? 'text-rose-400'
                : log.level === 'warn'
                ? 'text-amber-300'
                : log.level === 'success'
                ? 'text-emerald-400'
                : 'text-slate-300';

            const badgeBg =
              log.level === 'error'
                ? 'bg-rose-950/60 text-rose-300 border-rose-800/50'
                : log.level === 'warn'
                ? 'bg-amber-950/60 text-amber-300 border-amber-800/50'
                : log.level === 'success'
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/50'
                : 'bg-cyan-950/50 text-cyan-300 border-cyan-800/40';

            return (
              <div key={index} className="flex items-start gap-2 hover:bg-[#111827]/40 py-0.5 px-1 rounded">
                <span className="text-slate-500 select-none">[{log.timestamp}]</span>
                <span className={`px-1.5 py-0.2 rounded text-[9px] uppercase font-bold border ${badgeBg}`}>
                  {log.level}
                </span>
                <span className={color}>{log.message}</span>
              </div>
            );
          })}
          <div ref={terminalEndRef} />
        </div>
      </div>

      {/* Post Scan Summary & Next Actions */}
      {scanSummary && (
        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#10192a] to-[#0c121e] border border-cyan-500/40 shadow-2xl space-y-5 animate-in fade-in duration-300">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Scan Completed Successfully</h3>
                <p className="text-xs text-slate-400">
                  Detected {scanSummary.issuesFound} active configuration & code drift issues. Health score: {scanSummary.healthScore}%.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                id="scan-view-issues-cta"
                onClick={() => onNavigate('issues')}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 transition-all shadow-md flex items-center gap-1.5"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>View Detected Issues ({scanSummary.issuesFound})</span>
              </button>
              <button
                id="scan-view-mindmap-cta"
                onClick={() => onNavigate('mind-map')}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/40 transition-colors flex items-center gap-1.5"
              >
                <GitFork className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open Drift Mind Map</span>
              </button>
              <button
                id="scan-view-fixes-cta"
                onClick={() => onNavigate('fixes')}
                className="px-3.5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#1e293b] hover:bg-slate-700 transition-all flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                <span>Recommended Fix</span>
              </button>
              <button
                id="scan-view-report-cta"
                onClick={() => onNavigate('report')}
                className="px-3.5 py-2.5 rounded-xl text-xs font-semibold text-slate-300 bg-[#1e293b] hover:bg-slate-700 transition-all flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Reports</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-[#0e1422] border border-[#1e293b] text-center">
              <span className="text-[11px] text-slate-400 block mb-1">Total Keys Checked</span>
              <span className="text-xl font-extrabold font-mono text-cyan-400">142</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Across 3 environments</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0e1422] border border-rose-900/40 text-center">
              <span className="text-[11px] text-slate-400 block mb-1">Missing Keys Detected</span>
              <span className="text-xl font-extrabold font-mono text-rose-400">{scanSummary.missing}</span>
              <span className="text-[10px] text-rose-400/80 block mt-0.5">Absent in target env</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0e1422] border border-amber-900/40 text-center">
              <span className="text-[11px] text-slate-400 block mb-1">Orphaned Keys Detected</span>
              <span className="text-xl font-extrabold font-mono text-amber-400">{scanSummary.orphaned}</span>
              <span className="text-[10px] text-amber-400/80 block mt-0.5">Unreferenced in code</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0e1422] border border-purple-900/40 text-center">
              <span className="text-[11px] text-slate-400 block mb-1">Type Mismatches Detected</span>
              <span className="text-xl font-extrabold font-mono text-purple-400">{scanSummary.mismatch}</span>
              <span className="text-[10px] text-purple-400/80 block mt-0.5">Format & schema conflicts</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
