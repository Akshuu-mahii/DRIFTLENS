export type EnvironmentName = 'development' | 'staging' | 'production';

export type DriftType = 'missing' | 'orphaned' | 'type_mismatch';

export type IssueCategory = 'env_var' | 'import' | 'dependency' | 'schema' | 'dead_code';

export type Severity = 'critical' | 'high' | 'medium' | 'low';

export type IssueStatus = 'new' | 'still_unresolved' | 'resolved' | 'ignored';

export interface EnvStatusMap {
  development: boolean | 'ok' | 'missing' | 'mismatch' | 'orphaned';
  staging: boolean | 'ok' | 'missing' | 'mismatch' | 'orphaned';
  production: boolean | 'ok' | 'missing' | 'mismatch' | 'orphaned';
}

export interface MindMapWalkthrough {
  problem: string;
  evidence: string;
  impact: string;
  recommendedAction: string;
}

export interface FixSuggestion {
  explanation: string;
  diffBefore: string;
  diffAfter: string;
  targetFile: string;
  safeActionSummary: string;
}

export interface DriftIssue {
  id: string;
  type: DriftType;
  category: IssueCategory;
  title: string;
  keyOrTarget: string;
  filePath: string;
  line: number;
  column?: number;
  affectedEnvironments: {
    development: boolean;
    staging: boolean;
    production: boolean;
  };
  severity: Severity;
  status: IssueStatus;
  description: string;
  codeSnippet: {
    before: string;
    targetLine: number;
    surroundingContext: string;
  };
  firstDetectedAt: string;
  lastDetectedAt: string;
  repeatCount: number;
  mindMapData: MindMapWalkthrough;
  fixSuggestion: FixSuggestion;
}

export interface SecretItem {
  id: string;
  name: string;
  patternType: string;
  filePath: string;
  line: number;
  severity: Severity;
  detectedValueMasked: string;
  detectedValueFull: string;
  entropyScore: number;
  status: 'exposed' | 'warning' | 'secured';
  remediation: string;
  ruleId: string;
}

export interface ModuleNode {
  id: string;
  name: string;
  path: string;
  filesCount: number;
  healthScore: number;
  issuesCount: number;
  status: 'healthy' | 'warnings' | 'critical';
  submodules?: string[];
}

export interface ProjectConfig {
  id: string;
  name: string;
  repoUrl?: string;
  branch: string;
  lastScanTime: string;
  healthScore: number;
  filesCount: number;
  languages: { name: string; percentage: number; color: string }[];
  environments: {
    development: { varsCount: number; status: 'healthy' | 'warnings' | 'critical' };
    staging: { varsCount: number; status: 'healthy' | 'warnings' | 'critical' };
    production: { varsCount: number; status: 'healthy' | 'warnings' | 'critical' };
  };
  modules: ModuleNode[];
}

export interface ScanLogEntry {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
  step?: string;
}

export interface ScanRun {
  id: string;
  projectId: string;
  timestamp: string;
  healthScore: number;
  durationMs: number;
  stats: {
    filesScanned: number;
    issuesFound: number;
    missingCount: number;
    orphanedCount: number;
    typeMismatchCount: number;
    secretsDetected: number;
    resolvedCount: number;
  };
  logs: ScanLogEntry[];
  delta: {
    newIssues: number;
    resolvedIssues: number;
    stillUnresolved: number;
    scoreChange: number;
  };
}
