import { ProjectConfig, DriftIssue, SecretItem, ScanRun } from '../types';

export const initialProjects: ProjectConfig[] = [
  {
    id: 'proj_demo',
    name: 'My Project (Demo Scan)',
    repoUrl: 'github.com/developer/my-project',
    branch: 'main',
    lastScanTime: 'Just now',
    healthScore: 78,
    filesCount: 42,
    languages: [
      { name: 'Python', percentage: 55, color: '#3572A5' },
      { name: 'TypeScript', percentage: 32, color: '#3178c6' },
      { name: 'Config/Env', percentage: 13, color: '#eab308' },
    ],
    environments: {
      development: { varsCount: 24, status: 'healthy' },
      staging: { varsCount: 22, status: 'critical' },
      production: { varsCount: 23, status: 'warnings' },
    },
    modules: [
      { id: 'mod_payment', name: 'Payment & Billing Engine', path: 'payment.py', filesCount: 8, healthScore: 50, issuesCount: 1, status: 'critical' },
      { id: 'mod_api', name: 'API Client & Gateway', path: 'src/api', filesCount: 14, healthScore: 75, issuesCount: 1, status: 'warnings' },
      { id: 'mod_envs', name: 'Environment Settings', path: 'config/envs', filesCount: 6, healthScore: 68, issuesCount: 1, status: 'warnings' },
      { id: 'mod_core', name: 'Core Application Services', path: 'src/core', filesCount: 14, healthScore: 95, issuesCount: 0, status: 'healthy' },
    ],
  },
  {
    id: 'proj_nexus',
    name: 'Nexus Cloud Platform',
    repoUrl: 'github.com/nexus-cloud/platform-core',
    branch: 'main',
    lastScanTime: '2 hours ago',
    healthScore: 84,
    filesCount: 180,
    languages: [
      { name: 'TypeScript', percentage: 70, color: '#3178c6' },
      { name: 'React/TSX', percentage: 20, color: '#61dafb' },
      { name: 'YAML/Docker', percentage: 10, color: '#10b981' },
    ],
    environments: {
      development: { varsCount: 34, status: 'healthy' },
      staging: { varsCount: 32, status: 'warnings' },
      production: { varsCount: 31, status: 'warnings' },
    },
    modules: [
      { id: 'mod_billing', name: 'Billing & Subscriptions', path: 'src/services/billing', filesCount: 28, healthScore: 82, issuesCount: 1, status: 'warnings' },
      { id: 'mod_auth', name: 'Authentication & IAM', path: 'src/middleware/auth', filesCount: 34, healthScore: 90, issuesCount: 0, status: 'healthy' },
    ],
  },
];

export const initialIssues: DriftIssue[] = [
  {
    id: 'issue_payment_key',
    type: 'missing',
    category: 'env_var',
    title: 'PAYMENT_KEY missing in Staging',
    keyOrTarget: 'PAYMENT_KEY',
    filePath: 'payment.py',
    line: 18,
    column: 14,
    affectedEnvironments: {
      development: true,
      staging: false,
      production: true,
    },
    severity: 'critical',
    status: 'new',
    repeatCount: 1,
    firstDetectedAt: '2026-09-10 07:00:00',
    lastDetectedAt: '2026-09-10 07:00:00',
    description: 'Configuration key PAYMENT_KEY is referenced in code at payment.py:18 but is not defined in the Staging environment.',
    codeSnippet: {
      before: `def process_transaction(amount, currency):
    payment_key = os.getenv("PAYMENT_KEY")
    if not payment_key:
        raise ConfigurationError("PAYMENT_KEY not defined in environment")
    return stripe_client.charge(key=payment_key, amount=amount)`,
      targetLine: 18,
      surroundingContext: `import os
from exceptions import ConfigurationError

def process_transaction(amount, currency):
    payment_key = os.getenv("PAYMENT_KEY")
    if not payment_key:
        raise ConfigurationError("PAYMENT_KEY not defined in environment")
    return stripe_client.charge(key=payment_key, amount=amount)`,
    },
    mindMapData: {
      problem: 'PAYMENT_KEY is referenced in payment.py:18 but is not defined in Staging.',
      evidence: 'payment.py : Line 18',
      impact: 'Payment processing operations in Staging fail at runtime due to missing configuration key.',
      recommendedAction: 'Review the Staging configuration and add the required configuration key if it is expected for that environment.',
    },
    fixSuggestion: {
      explanation: 'Define PAYMENT_KEY in staging configuration to ensure transaction processing works in staging tests.',
      diffBefore: `# config/.env.staging
DATABASE_URL="postgres://staging-db:5432/app"
# (Missing PAYMENT_KEY)`,
      diffAfter: `# config/.env.staging
DATABASE_URL="postgres://staging-db:5432/app"
PAYMENT_KEY="\${STAGING_PAYMENT_KEY_REF}"`,
      targetFile: 'config/.env.staging',
      safeActionSummary: 'Add PAYMENT_KEY configuration reference to Staging environment file',
    },
  },
  {
    id: 'issue_legacy_api_url',
    type: 'orphaned',
    category: 'env_var',
    title: 'LEGACY_API_URL defined in Staging & Production but unreferenced',
    keyOrTarget: 'LEGACY_API_URL',
    filePath: 'config/envs/.env.staging',
    line: 12,
    column: 1,
    affectedEnvironments: {
      development: false,
      staging: true,
      production: true,
    },
    severity: 'low',
    status: 'new',
    repeatCount: 1,
    firstDetectedAt: '2026-09-10 07:00:00',
    lastDetectedAt: '2026-09-10 07:00:00',
    description: 'Configuration key LEGACY_API_URL is defined in Staging and Production environments, but no code reference was found in the codebase.',
    codeSnippet: {
      before: `APP_PORT=8080
LEGACY_API_URL=https://old-api.internal.network/v1
CACHE_TTL=3600`,
      targetLine: 12,
      surroundingContext: `# External integrations
APP_PORT=8080
LEGACY_API_URL=https://old-api.internal.network/v1
CACHE_TTL=3600`,
    },
    mindMapData: {
      problem: 'Configuration key is defined in an environment but no code reference was found.',
      evidence: 'Defined in STAGING, PRODUCTION. 0 AST matches across repository.',
      impact: 'Creates configuration bloat and confusion during maintenance.',
      recommendedAction: 'Candidate for review or safe removal from environment configs.',
    },
    fixSuggestion: {
      explanation: 'Remove unreferenced LEGACY_API_URL from Staging and Production configuration templates.',
      diffBefore: `APP_PORT=8080
LEGACY_API_URL=https://old-api.internal.network/v1
CACHE_TTL=3600`,
      diffAfter: `APP_PORT=8080
CACHE_TTL=3600`,
      targetFile: 'config/envs/.env.staging',
      safeActionSummary: 'Remove unreferenced LEGACY_API_URL from environment configs',
    },
  },
  {
    id: 'issue_max_retry_count',
    type: 'type_mismatch',
    category: 'schema',
    title: 'MAX_RETRY_COUNT inconsistent types between environments',
    keyOrTarget: 'MAX_RETRY_COUNT',
    filePath: 'src/api/client.py',
    line: 24,
    column: 18,
    affectedEnvironments: {
      development: true,
      staging: true,
      production: true,
    },
    severity: 'high',
    status: 'still_unresolved',
    repeatCount: 2,
    firstDetectedAt: '2026-09-09 18:20:00',
    lastDetectedAt: '2026-09-10 07:00:00',
    description: 'Development → Number (3), Staging → Number (3), Production → String ("3"). Production type divergence can cause strict typing or validation failures.',
    codeSnippet: {
      before: `retry_count = os.getenv("MAX_RETRY_COUNT", 3)
# Expected integer in production client initialization
client = HttpClient(retries=retry_count)`,
      targetLine: 24,
      surroundingContext: `import os

def get_api_client():
    retry_count = os.getenv("MAX_RETRY_COUNT", 3)
    # Expected integer in production client initialization
    return HttpClient(retries=retry_count)`,
    },
    mindMapData: {
      problem: 'The same configuration key has inconsistent types/formats between environments.',
      evidence: 'Development → Number | Staging → Number | Production → String',
      impact: 'String type in Production may cause runtime validation errors or unexpected string concatenation.',
      recommendedAction: 'Harmonize MAX_RETRY_COUNT to numeric format across all environments.',
    },
    fixSuggestion: {
      explanation: 'Ensure MAX_RETRY_COUNT is parsed as integer and formatted as integer in production .env.',
      diffBefore: `# .env.production
MAX_RETRY_COUNT="3"`,
      diffAfter: `# .env.production
MAX_RETRY_COUNT=3`,
      targetFile: '.env.production',
      safeActionSummary: 'Update MAX_RETRY_COUNT in production to integer 3',
    },
  },
  {
    id: 'issue_jwt_expiry',
    type: 'type_mismatch',
    category: 'schema',
    title: 'SESSION_EXPIRY format mismatch across environments',
    keyOrTarget: 'SESSION_EXPIRY',
    filePath: 'src/core/auth.py',
    line: 32,
    column: 15,
    affectedEnvironments: {
      development: true,
      staging: true,
      production: false,
    },
    severity: 'medium',
    status: 'new',
    repeatCount: 1,
    firstDetectedAt: '2026-09-10 07:00:00',
    lastDetectedAt: '2026-09-10 07:00:00',
    description: 'Development provides numeric seconds (3600), Staging provides numeric seconds (3600), while Production provides duration string "1h".',
    codeSnippet: {
      before: `session_ttl = int(os.environ["SESSION_EXPIRY"])`,
      targetLine: 32,
      surroundingContext: `def create_session():
    session_ttl = int(os.environ["SESSION_EXPIRY"])
    return session_store.generate(ttl=session_ttl)`,
    },
    mindMapData: {
      problem: 'Inconsistent data representation for session expiry configuration.',
      evidence: 'Dev: 3600 (Number), Staging: 3600 (Number), Prod: "1h" (String)',
      impact: 'Calling int() in production on string "1h" raises ValueError: invalid literal for int().',
      recommendedAction: 'Standardize SESSION_EXPIRY to integer seconds across all environments.',
    },
    fixSuggestion: {
      explanation: 'Change production SESSION_EXPIRY value to integer 3600.',
      diffBefore: `SESSION_EXPIRY="1h"`,
      diffAfter: `SESSION_EXPIRY=3600`,
      targetFile: '.env.production',
      safeActionSummary: 'Change SESSION_EXPIRY in production to 3600',
    },
  },
];

export const initialSecrets: SecretItem[] = [
  {
    id: 'sec_001',
    name: 'API_KEY',
    patternType: 'Service API Key',
    filePath: 'src/api/client.py',
    line: 8,
    severity: 'critical',
    detectedValueMasked: 'Present (Masked)',
    detectedValueFull: 'Present',
    entropyScore: 4.8,
    status: 'secured',
    ruleId: 'API_KEY_PRESENT',
    remediation: 'Key presence validated via environment injection. Raw secret value is masked and protected.',
  },
  {
    id: 'sec_002',
    name: 'DATABASE_PASSWORD',
    patternType: 'Database Secret',
    filePath: 'config/envs/.env.production',
    line: 4,
    severity: 'critical',
    detectedValueMasked: 'Present (Masked)',
    detectedValueFull: 'Present',
    entropyScore: 4.9,
    status: 'secured',
    ruleId: 'DATABASE_PASSWORD_PRESENT',
    remediation: 'Database credential presence verified. Value never revealed or logged by DriftLens.',
  },
  {
    id: 'sec_003',
    name: 'PAYMENT_TOKEN',
    patternType: 'Payment Gateway Secret',
    filePath: 'payment.py',
    line: 12,
    severity: 'critical',
    detectedValueMasked: 'Present (Masked)',
    detectedValueFull: 'Present',
    entropyScore: 4.7,
    status: 'secured',
    ruleId: 'PAYMENT_TOKEN_PRESENT',
    remediation: 'Protected token. Value masked by default; raw secret values are never displayed.',
  },
  {
    id: 'sec_004',
    name: 'JWT_SIGNING_SECRET',
    patternType: 'Auth Token Signing Key',
    filePath: 'src/core/auth.py',
    line: 15,
    severity: 'high',
    detectedValueMasked: 'Present (Masked)',
    detectedValueFull: 'Present',
    entropyScore: 4.6,
    status: 'secured',
    ruleId: 'JWT_SECRET_PRESENT',
    remediation: 'Session key verified as present across deployment environments. Zero raw secrets exposed.',
  },
];

export const initialHistory: ScanRun[] = [
  {
    id: 'scan_today',
    projectId: 'proj_demo',
    timestamp: 'Today, 07:00 AM',
    healthScore: 78,
    durationMs: 2400,
    stats: {
      filesScanned: 42,
      issuesFound: 3,
      missingCount: 1,
      orphanedCount: 1,
      typeMismatchCount: 1,
      secretsDetected: 4,
      resolvedCount: 2,
    },
    logs: [
      { timestamp: '07:00:00.100', level: 'info', message: 'Initialized DriftLens AST scan engine on My Project (Demo Scan)', step: 'init' },
      { timestamp: '07:00:00.800', level: 'warn', message: 'Detected missing configuration PAYMENT_KEY in Staging (payment.py:18)', step: 'diff' },
      { timestamp: '07:00:01.400', level: 'warn', message: 'Detected orphaned configuration LEGACY_API_URL in Staging & Production', step: 'diff' },
      { timestamp: '07:00:01.900', level: 'warn', message: 'Detected type mismatch on MAX_RETRY_COUNT between Dev/Staging and Production', step: 'diff' },
      { timestamp: '07:00:02.400', level: 'success', message: 'Scan complete. 2 New Issues, 1 Still Unresolved, 4 Secrets Protected.', step: 'finish' },
    ],
    delta: {
      newIssues: 2,
      resolvedIssues: 0,
      stillUnresolved: 1,
      scoreChange: +4,
    },
  },
  {
    id: 'scan_previous',
    projectId: 'proj_demo',
    timestamp: 'Previous Scan (Yesterday, 04:30 PM)',
    healthScore: 74,
    durationMs: 2800,
    stats: {
      filesScanned: 42,
      issuesFound: 3,
      missingCount: 2,
      orphanedCount: 1,
      typeMismatchCount: 0,
      secretsDetected: 4,
      resolvedCount: 1,
    },
    logs: [
      { timestamp: '16:30:00.120', level: 'info', message: 'Started automated CI/CD pull request verification', step: 'init' },
      { timestamp: '16:30:01.500', level: 'error', message: 'Missing STRIPE_WEBHOOK_SECRET in Staging', step: 'diff' },
      { timestamp: '16:30:02.800', level: 'success', message: 'Scan finished. 3 Issues detected.', step: 'finish' },
    ],
    delta: {
      newIssues: 3,
      resolvedIssues: 1,
      stillUnresolved: 0,
      scoreChange: +2,
    },
  },
  {
    id: 'scan_earlier',
    projectId: 'proj_demo',
    timestamp: 'Earlier Scan (3 days ago)',
    healthScore: 72,
    durationMs: 3100,
    stats: {
      filesScanned: 40,
      issuesFound: 4,
      missingCount: 2,
      orphanedCount: 2,
      typeMismatchCount: 0,
      secretsDetected: 4,
      resolvedCount: 2,
    },
    logs: [
      { timestamp: '11:15:00.080', level: 'info', message: 'Baseline drift audit for repository', step: 'init' },
      { timestamp: '11:15:02.100', level: 'success', message: '2 Resolved configuration discrepancies verified.', step: 'diff' },
      { timestamp: '11:15:03.100', level: 'success', message: 'Initial baseline created.', step: 'finish' },
    ],
    delta: {
      newIssues: 0,
      resolvedIssues: 2,
      stillUnresolved: 2,
      scoreChange: 0,
    },
  },
];
