import React, { useState, useEffect } from 'react';
import { Sidebar, NavRoute } from './components/Sidebar';
import { Header } from './components/Header';
import { HomeView } from './components/HomeView';
import { UploadView } from './components/UploadView';
import { ScanView } from './components/ScanView';
import { HealthMapView } from './components/HealthMapView';
import { IssuesView } from './components/IssuesView';
import { MindMapView } from './components/MindMapView';
import { RecommendedFixView } from './components/RecommendedFixView';
import { SecretShieldView } from './components/SecretShieldView';
import { HistoryView } from './components/HistoryView';
import { SafeReportView } from './components/SafeReportView';
import {
  initialProjects,
  initialIssues,
  initialSecrets,
  initialHistory,
} from './data/mockData';
import { ProjectConfig, DriftIssue, SecretItem, ScanRun } from './types';
import { CheckCircle2, Sparkles, X } from 'lucide-react';

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<NavRoute>('home');
  const [projects, setProjects] = useState<ProjectConfig[]>(initialProjects);
  const [activeProjectId, setActiveProjectId] = useState<string>(initialProjects[0].id);
  const [issues, setIssues] = useState<DriftIssue[]>(initialIssues);
  const [secrets, setSecrets] = useState<SecretItem[]>(initialSecrets);
  const [history, setHistory] = useState<ScanRun[]>(initialHistory);
  const [isScanning, setIsScanning] = useState(false);

  // Selected issue for direct jump into Mind Map or Fixes
  const [selectedIssueId, setSelectedIssueId] = useState<string>(initialIssues[0].id);

  // Notification Toast state
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string } | null>(null);

  const showToast = (title: string, desc: string) => {
    setToastMessage({ title, desc });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Sync initial data from backend API
  useEffect(() => {
    async function loadData() {
      try {
        const [projRes, issuesRes, secretsRes, historyRes] = await Promise.allSettled([
          fetch('/api/projects').then((r) => r.json()),
          fetch('/api/issues').then((r) => r.json()),
          fetch('/api/secrets').then((r) => r.json()),
          fetch('/api/history').then((r) => r.json()),
        ]);

        if (projRes.status === 'fulfilled' && projRes.value?.projects) {
          setProjects(projRes.value.projects);
          if (projRes.value.activeProjectId) {
            setActiveProjectId(projRes.value.activeProjectId);
          }
        }
        if (issuesRes.status === 'fulfilled' && issuesRes.value?.issues) {
          setIssues(issuesRes.value.issues);
        }
        if (secretsRes.status === 'fulfilled' && secretsRes.value?.secrets) {
          setSecrets(secretsRes.value.secrets);
        }
        if (historyRes.status === 'fulfilled' && historyRes.value?.history) {
          setHistory(historyRes.value.history);
        }
      } catch (err) {
        console.warn('Backend initialized with local fallback dataset.');
      }
    }
    loadData();
  }, []);

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];

  const handleSelectProject = (id: string) => {
    setActiveProjectId(id);
    fetch('/api/projects/select', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId: id }),
    }).catch(() => {});
    showToast('Switched Codebase', `Now monitoring ${projects.find((p) => p.id === id)?.name || id}`);
  };

  const handleApplyFix = async (issueId: string) => {
    try {
      const res = await fetch(`/api/issues/${issueId}/apply`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setIssues((prev) =>
          prev.map((i) => (i.id === issueId ? { ...i, status: 'resolved' } : i))
        );
        if (data.healthScore && activeProject) {
          activeProject.healthScore = data.healthScore;
          setProjects([...projects]);
        }
        showToast('Fix Successfully Applied!', `Patch merged for ${data.issue?.keyOrTarget}. Codebase health improved.`);
      }
    } catch {
      // Local fallback
      setIssues((prev) =>
        prev.map((i) => (i.id === issueId ? { ...i, status: 'resolved' } : i))
      );
      if (activeProject) {
        activeProject.healthScore = Math.min(100, activeProject.healthScore + 6);
        setProjects([...projects]);
      }
      showToast('Fix Successfully Applied!', 'Patch merged. Codebase health improved.');
    }
  };

  const handleIgnoreIssue = async (issueId: string) => {
    try {
      await fetch(`/api/issues/${issueId}/ignore`, { method: 'POST' });
    } catch {}
    setIssues((prev) =>
      prev.map((i) => (i.id === issueId ? { ...i, status: 'ignored' } : i))
    );
    showToast('Issue Ignored', 'Finding muted from active alerts.');
  };

  const handleRemediateSecret = async (secretId: string) => {
    try {
      const res = await fetch(`/api/secrets/${secretId}/remediate`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSecrets((prev) =>
          prev.map((s) => (s.id === secretId ? { ...s, status: 'secured' } : s))
        );
        if (data.healthScore && activeProject) {
          activeProject.healthScore = data.healthScore;
          setProjects([...projects]);
        }
        showToast('Secret Secured!', 'Credential rotated & removed from repository.');
      }
    } catch {
      setSecrets((prev) =>
        prev.map((s) => (s.id === secretId ? { ...s, status: 'secured' } : s))
      );
      showToast('Secret Secured!', 'Credential rotated & removed from repository.');
    }
  };

  const handleTriggerScan = () => {
    setCurrentRoute('scan');
  };

  const handleScanCompleted = (
    newIssues: DriftIssue[],
    newHistoryRun: ScanRun,
    newScore: number
  ) => {
    setIssues(newIssues);
    setHistory((prev) => [newHistoryRun, ...prev]);
    if (activeProject) {
      activeProject.healthScore = newScore;
      activeProject.lastScanTime = 'Just now';
      setProjects([...projects]);
    }
    showToast('Parity Scan Finished', `Cataloged ${newIssues.filter((i) => i.status !== 'resolved').length} active drifts. Parity: ${newScore}%`);
  };

  const handleProjectUploaded = (newProject: ProjectConfig) => {
    setProjects((prev) => [newProject, ...prev]);
    setActiveProjectId(newProject.id);
    showToast('Project Ingested', `${newProject.name} is ready for multi-environment drift analysis.`);
  };

  const handleSelectIssueForMindMap = (issue: DriftIssue) => {
    setSelectedIssueId(issue.id);
    setCurrentRoute('mind-map');
  };

  const handleSelectIssueForFix = (issue: DriftIssue) => {
    setSelectedIssueId(issue.id);
    setCurrentRoute('fixes');
  };

  const unresolvedCount = issues.filter(
    (i) => i.status !== 'resolved' && i.status !== 'ignored'
  ).length;
  const exposedSecretsCount = secrets.filter((s) => s.status === 'exposed').length;

  return (
    <div className="flex min-h-screen bg-[#07090e] text-[#e2e8f0] antialiased">
      {/* Persistent Left Sidebar */}
      <Sidebar
        currentRoute={currentRoute}
        onNavigate={setCurrentRoute}
        projects={projects}
        activeProject={activeProject}
        onSelectProject={handleSelectProject}
        issues={issues}
        exposedSecretsCount={exposedSecretsCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
        {/* Sticky Top Header */}
        <Header
          project={activeProject}
          onTriggerScan={handleTriggerScan}
          isScanning={isScanning}
          onOpenFixes={() => setCurrentRoute('fixes')}
          onOpenReport={() => setCurrentRoute('report')}
          unresolvedCount={unresolvedCount}
        />

        {/* Route Views */}
        <main className="flex-1 pb-16">
          {currentRoute === 'home' && (
            <HomeView
              project={activeProject}
              issues={issues}
              secrets={secrets}
              history={history}
              onNavigate={setCurrentRoute}
              onTriggerScan={handleTriggerScan}
            />
          )}

          {currentRoute === 'upload' && (
            <UploadView
              onProjectUploaded={handleProjectUploaded}
              onNavigateToScan={() => setCurrentRoute('scan')}
            />
          )}

          {currentRoute === 'scan' && (
            <ScanView
              project={activeProject}
              onNavigate={setCurrentRoute}
              onScanCompleted={handleScanCompleted}
              isScanning={isScanning}
              setIsScanning={setIsScanning}
            />
          )}

          {currentRoute === 'health-map' && (
            <HealthMapView
              project={activeProject}
              issues={issues}
              onNavigate={setCurrentRoute}
              onSelectIssueForMindMap={handleSelectIssueForMindMap}
            />
          )}

          {currentRoute === 'issues' && (
            <IssuesView
              issues={issues}
              onNavigate={setCurrentRoute}
              onSelectIssueForMindMap={handleSelectIssueForMindMap}
              onSelectIssueForFix={handleSelectIssueForFix}
              onApplyFix={handleApplyFix}
            />
          )}

          {currentRoute === 'mind-map' && (
            <MindMapView
              project={activeProject}
              issues={issues}
              selectedIssueId={selectedIssueId}
              onNavigate={setCurrentRoute}
              onSelectIssueForFix={handleSelectIssueForFix}
              onApplyFix={handleApplyFix}
            />
          )}

          {currentRoute === 'fixes' && (
            <RecommendedFixView
              issues={issues}
              selectedIssueId={selectedIssueId}
              onApplyFix={handleApplyFix}
              onIgnoreIssue={handleIgnoreIssue}
            />
          )}

          {currentRoute === 'secrets' && (
            <SecretShieldView
              secrets={secrets}
              onRemediateSecret={handleRemediateSecret}
            />
          )}

          {currentRoute === 'history' && (
            <HistoryView
              history={history}
              onTriggerNewScan={handleTriggerScan}
            />
          )}

          {currentRoute === 'report' && (
            <SafeReportView
              project={activeProject}
              issues={issues}
              secrets={secrets}
              history={history}
              onNavigate={setCurrentRoute}
              onTriggerScan={handleTriggerScan}
            />
          )}
        </main>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-[#111827] border border-cyan-500/40 shadow-2xl flex items-start gap-3 max-w-sm animate-in fade-in slide-in-from-bottom-5 duration-300">
          <div className="p-1 rounded-full bg-cyan-500/10 text-cyan-400 mt-0.5">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="flex-1 space-y-0.5">
            <h4 className="text-xs font-bold text-white">{toastMessage.title}</h4>
            <p className="text-[11px] text-slate-300 leading-snug">{toastMessage.desc}</p>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="text-slate-500 hover:text-slate-300 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
