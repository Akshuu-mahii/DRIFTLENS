import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { initialProjects, initialIssues, initialSecrets, initialHistory } from './src/data/mockData.ts';
import { DriftIssue, ProjectConfig, SecretItem, ScanRun, ScanLogEntry } from './src/types.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory state store
let currentProjectId = 'proj_nexus';
let projects: ProjectConfig[] = JSON.parse(JSON.stringify(initialProjects));
let issues: DriftIssue[] = JSON.parse(JSON.stringify(initialIssues));
let secrets: SecretItem[] = JSON.parse(JSON.stringify(initialSecrets));
let history: ScanRun[] = JSON.parse(JSON.stringify(initialHistory));

// Lazy Gemini client helper
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Compute dynamic project health score
function calculateHealth(projectIssues: DriftIssue[], projectSecrets: SecretItem[]): number {
  let penalty = 0;
  const activeIssues = projectIssues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored');
  activeIssues.forEach((issue) => {
    if (issue.severity === 'critical') penalty += 10;
    else if (issue.severity === 'high') penalty += 6;
    else if (issue.severity === 'medium') penalty += 3;
    else penalty += 1;
  });

  const exposedSecrets = projectSecrets.filter((s) => s.status === 'exposed');
  penalty += exposedSecrets.length * 8;

  const score = Math.max(15, Math.min(100, 100 - penalty));
  return score;
}

// ======================== API ROUTES ========================

// 1. Get all projects
app.get('/api/projects', (req, res) => {
  const current = projects.find((p) => p.id === currentProjectId) || projects[0];
  current.healthScore = calculateHealth(issues, secrets);
  res.json({ projects, activeProjectId: currentProjectId });
});

// 2. Select active project
app.post('/api/projects/select', (req, res) => {
  const { projectId } = req.body;
  if (projects.some((p) => p.id === projectId)) {
    currentProjectId = projectId;
    return res.json({ success: true, activeProjectId: currentProjectId });
  }
  res.status(404).json({ error: 'Project not found' });
});

// 3. Upload or connect repository
app.post('/api/projects/upload', (req, res) => {
  const { name, repoUrl, fileCount, sampleType } = req.body;
  const newId = `proj_${Date.now()}`;
  const detectedLanguages = [
    { name: 'TypeScript', percentage: 64, color: '#3178c6' },
    { name: 'React / JSX', percentage: 24, color: '#61dafb' },
    { name: 'JSON / Env', percentage: 8, color: '#eab308' },
    { name: 'Docker / CI', percentage: 4, color: '#10b981' },
  ];

  const newProject: ProjectConfig = {
    id: newId,
    name: name || (sampleType ? `${sampleType} (Imported)` : 'Uploaded Project'),
    repoUrl: repoUrl || undefined,
    branch: 'main',
    lastScanTime: 'Pending initial scan',
    healthScore: 78,
    filesCount: fileCount || 142,
    languages: detectedLanguages,
    environments: {
      development: { varsCount: 32, status: 'warnings' },
      staging: { varsCount: 28, status: 'critical' },
      production: { varsCount: 25, status: 'critical' },
    },
    modules: [
      { id: `mod_${Date.now()}_1`, name: 'Core Application Service', path: 'src/core', filesCount: 45, healthScore: 82, issuesCount: 2, status: 'warnings' },
      { id: `mod_${Date.now()}_2`, name: 'Authentication & Tokens', path: 'src/auth', filesCount: 22, healthScore: 60, issuesCount: 3, status: 'critical' },
      { id: `mod_${Date.now()}_3`, name: 'Environment Configurations', path: 'config', filesCount: 8, healthScore: 50, issuesCount: 3, status: 'critical' },
    ],
  };

  projects.unshift(newProject);
  currentProjectId = newId;

  res.json({
    success: true,
    project: newProject,
    stats: {
      totalFiles: newProject.filesCount,
      languages: detectedLanguages,
      configFilesFound: ['.env.development', '.env.staging', '.env.production', 'package.json', 'tsconfig.json'],
    },
  });
});

// 4. Get detected issues
app.get('/api/issues', (req, res) => {
  res.json({
    issues,
    summary: {
      total: issues.length,
      missing: issues.filter((i) => i.type === 'missing').length,
      orphaned: issues.filter((i) => i.type === 'orphaned').length,
      typeMismatch: issues.filter((i) => i.type === 'type_mismatch').length,
      unresolved: issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored').length,
      resolved: issues.filter((i) => i.status === 'resolved').length,
    },
  });
});

// 5. Apply fix for an issue
app.post('/api/issues/:id/apply', (req, res) => {
  const { id } = req.params;
  const issue = issues.find((i) => i.id === id);
  if (!issue) {
    return res.status(404).json({ error: 'Issue not found' });
  }

  issue.status = 'resolved';
  const newHealth = calculateHealth(issues, secrets);

  const activeProj = projects.find((p) => p.id === currentProjectId);
  if (activeProj) {
    activeProj.healthScore = newHealth;
  }

  // Update or append scan run in history
  const currentRun = history[history.length - 1];
  if (currentRun) {
    currentRun.stats.resolvedCount += 1;
    currentRun.delta.resolvedIssues += 1;
    currentRun.delta.scoreChange += 2;
  }

  res.json({
    success: true,
    issue,
    healthScore: newHealth,
    message: `Fix successfully applied to ${issue.filePath}. Issue marked as Resolved.`,
  });
});

// 6. Ignore issue
app.post('/api/issues/:id/ignore', (req, res) => {
  const { id } = req.params;
  const issue = issues.find((i) => i.id === id);
  if (!issue) {
    return res.status(404).json({ error: 'Issue not found' });
  }
  issue.status = 'ignored';
  res.json({ success: true, issue });
});

// 7. Get secret shield findings
app.get('/api/secrets', (req, res) => {
  res.json({
    secrets,
    count: secrets.length,
    exposedCount: secrets.filter((s) => s.status === 'exposed').length,
  });
});

// 8. Remediate a secret
app.post('/api/secrets/:id/remediate', (req, res) => {
  const { id } = req.params;
  const secret = secrets.find((s) => s.id === id);
  if (!secret) {
    return res.status(404).json({ error: 'Secret not found' });
  }
  secret.status = 'secured';
  const newHealth = calculateHealth(issues, secrets);
  res.json({ success: true, secret, healthScore: newHealth });
});

// 9. Scan codebase across Dev, Staging, and Production
app.post('/api/scan', (req, res) => {
  const now = new Date();
  const timeStr = now.toLocaleTimeString();

  const generatedLogs: ScanLogEntry[] = [
    { timestamp: `${timeStr}.050`, level: 'info', message: 'Starting AST parsing across 384 project files...', step: 'ast' },
    { timestamp: `${timeStr}.420`, level: 'info', message: 'Extracted 142 configuration key references from codebase AST', step: 'extract' },
    { timestamp: `${timeStr}.880`, level: 'info', message: 'Evaluating environment parity: .env.development vs .env.staging vs .env.production', step: 'diff' },
    { timestamp: `${timeStr}.210`, level: 'warn', message: 'Missing drift detected: NEXT_PUBLIC_STRIPE_KEY absent from staging & production', step: 'diff' },
    { timestamp: `${timeStr}.460`, level: 'warn', message: 'Orphaned drift detected: LEGACY_REDIS_PASSWORD defined in configs but unreferenced in code', step: 'diff' },
    { timestamp: `${timeStr}.730`, level: 'error', message: 'Type mismatch: SESSION_TIMEOUT_SECONDS defined as number in dev, string "24h" in prod', step: 'type_check' },
    { timestamp: `${timeStr}.010`, level: 'error', message: 'Secret Shield: 4 exposed credentials detected in tracked source files', step: 'secrets' },
    { timestamp: `${timeStr}.350`, level: 'success', message: 'Scan finished in 2.8s. Drift mind map & remediation topology updated.', step: 'finish' },
  ];

  // Increment repeat count for unresolved issues
  issues.forEach((issue) => {
    if (issue.status === 'new') {
      issue.status = 'still_unresolved';
      issue.repeatCount += 1;
    } else if (issue.status === 'still_unresolved') {
      issue.repeatCount += 1;
      issue.lastDetectedAt = now.toISOString().replace('T', ' ').slice(0, 19);
    }
  });

  const healthScore = calculateHealth(issues, secrets);
  const activeProj = projects.find((p) => p.id === currentProjectId);
  if (activeProj) {
    activeProj.healthScore = healthScore;
    activeProj.lastScanTime = 'Just now';
  }

  const newScanRun: ScanRun = {
    id: `scan_${Date.now()}`,
    projectId: currentProjectId,
    timestamp: now.toISOString().replace('T', ' ').slice(0, 19),
    healthScore,
    durationMs: 2840,
    stats: {
      filesScanned: activeProj?.filesCount || 384,
      issuesFound: issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored').length,
      missingCount: issues.filter((i) => i.type === 'missing' && i.status !== 'resolved').length,
      orphanedCount: issues.filter((i) => i.type === 'orphaned' && i.status !== 'resolved').length,
      typeMismatchCount: issues.filter((i) => i.type === 'type_mismatch' && i.status !== 'resolved').length,
      secretsDetected: secrets.filter((s) => s.status === 'exposed').length,
      resolvedCount: issues.filter((i) => i.status === 'resolved').length,
    },
    logs: generatedLogs,
    delta: {
      newIssues: 0,
      resolvedIssues: 0,
      stillUnresolved: issues.filter((i) => i.status === 'still_unresolved').length,
      scoreChange: 0,
    },
  };

  history.unshift(newScanRun);

  res.json({
    success: true,
    scan: newScanRun,
    issues,
    healthScore,
  });
});

// 10. Scan history
app.get('/api/history', (req, res) => {
  res.json({ history });
});

// 10b. Generate Safe Consolidated Drift Report (Zero Raw Secrets)
app.get('/api/report', (req, res) => {
  const activeProj = projects.find((p) => p.id === currentProjectId) || projects[0];
  const now = new Date();
  const unresolvedIssues = issues.filter((i) => i.status !== 'resolved' && i.status !== 'ignored');

  const lines: string[] = [
    `# DriftLens Configuration Drift & Health Audit Report`,
    `**Target Codebase:** ${activeProj.name} (\`${activeProj.branch || 'main'}\`)`,
    `**Audit Date:** ${now.toUTCString()}`,
    `**Health Score:** ${activeProj.healthScore}%`,
    `**Analyzed Files:** ${activeProj.filesCount}`,
    `**Security Certification:** Safe Metadata Only — Zero raw credentials/secrets exported.`,
    ``,
    `## Summary of Findings`,
    `- Missing Configuration Drifts: ${issues.filter((i) => i.type === 'missing' && i.status !== 'resolved').length}`,
    `- Orphaned Configuration Drifts: ${issues.filter((i) => i.type === 'orphaned' && i.status !== 'resolved').length}`,
    `- Type & Schema Inconsistencies: ${issues.filter((i) => i.type === 'type_mismatch' && i.status !== 'resolved').length}`,
    `- Credential Exposure Findings: ${secrets.filter((s) => s.status === 'exposed').length} (Masked metadata only)`,
    `- Resolved Issues to Date: ${issues.filter((i) => i.status === 'resolved').length}`,
    ``,
    `## Critical Issues Detail`,
  ];

  unresolvedIssues.forEach((issue, idx) => {
    lines.push(`### ${idx + 1}. [${issue.severity.toUpperCase()}] ${issue.keyOrTarget} (${issue.type.replace('_', ' ')})`);
    lines.push(`- **Location:** \`${issue.filePath}:${issue.line}\``);
    lines.push(`- **Problem:** ${issue.mindMapData.problem}`);
    lines.push(`- **Evidence:** ${issue.mindMapData.evidence}`);
    lines.push(`- **Impact:** ${issue.mindMapData.impact}`);
    lines.push(`- **Recommended Safe Action:** ${issue.mindMapData.recommendedAction}`);
    lines.push(``);
  });

  res.json({
    reportId: `REP-${Date.now().toString(36).toUpperCase()}`,
    timestamp: now.toISOString(),
    project: activeProj.name,
    healthScore: activeProj.healthScore,
    markdown: lines.join('\n'),
    unresolvedCount: unresolvedIssues.length,
  });
});

// 11. AI-generated fix suggestion (Safe Metadata Only - No actual secrets sent!)
app.post('/api/ai/fix', async (req, res) => {
  const { issueId, safeMetadata } = req.body;

  const targetIssue = issues.find((i) => i.id === issueId);
  if (!targetIssue) {
    return res.status(404).json({ error: 'Issue not found' });
  }

  // Strictly enforce safe metadata only:
  // keyName, type, category, targetFile, problem description.
  // NEVER send actual secret values or live credentials!
  const sanitizedInput = {
    keyOrTarget: targetIssue.keyOrTarget,
    driftType: targetIssue.type,
    category: targetIssue.category,
    filePath: targetIssue.filePath,
    line: targetIssue.line,
    affectedEnvironments: targetIssue.affectedEnvironments,
    problemSummary: targetIssue.mindMapData.problem,
  };

  const ai = getAiClient();
  if (ai) {
    try {
      const prompt = `You are DriftLens AI, an expert DevSecOps configuration and codebase drift remediation specialist.
Analyze this codebase drift issue using ONLY safe metadata (no secret values):
- Key / Target: "${sanitizedInput.keyOrTarget}"
- Drift Type: "${sanitizedInput.driftType}"
- Category: "${sanitizedInput.category}"
- File: "${sanitizedInput.filePath}" at line ${sanitizedInput.line}
- Affected Environments: Dev=${sanitizedInput.affectedEnvironments.development}, Staging=${sanitizedInput.affectedEnvironments.staging}, Prod=${sanitizedInput.affectedEnvironments.production}
- Problem: ${sanitizedInput.problemSummary}

Provide a concise, production-grade fix suggestion.
Return ONLY valid JSON matching this structure:
{
  "explanation": "concise 1-2 sentence explanation of why this fix solves the drift without breaking other environments",
  "diffBefore": "code or config snippet before fix",
  "diffAfter": "code or config snippet after fix",
  "safeActionSummary": "short actionable directive (e.g. 'Add NEXT_PUBLIC_STRIPE_KEY to .env.staging and .env.production templates')"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      const text = response.text || '';
      // Clean potential markdown wrapping
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleaned);

      targetIssue.fixSuggestion = {
        explanation: parsed.explanation || targetIssue.fixSuggestion.explanation,
        diffBefore: parsed.diffBefore || targetIssue.fixSuggestion.diffBefore,
        diffAfter: parsed.diffAfter || targetIssue.fixSuggestion.diffAfter,
        targetFile: targetIssue.fixSuggestion.targetFile,
        safeActionSummary: parsed.safeActionSummary || targetIssue.fixSuggestion.safeActionSummary,
      };

      return res.json({ success: true, fixSuggestion: targetIssue.fixSuggestion, source: 'gemini' });
    } catch (err: any) {
      console.warn('Gemini API call returned fallback:', err?.message);
    }
  }

  // Fallback heuristic suggestion
  res.json({
    success: true,
    fixSuggestion: targetIssue.fixSuggestion,
    source: 'heuristic',
  });
});

// ======================== VITE MIDDLEWARE ========================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DriftLens Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
